import {BrowserProvider,Contract,ContractFactory,getAddress,hexlify,isAddress,keccak256,toUtf8Bytes} from 'ethers';
import artifact from './generated/pathfolio-sbt.json';
import type {Activity} from './portfolio-types';
export const CHAIN_ID=11155111;
export const EXPLORER='https://sepolia.etherscan.io';
// Populated only after an actual user-signed deployment has been verified.
export const OFFICIAL_CONTRACT='0x86E9162216353DC5aAa464F902BD2825CfBF6181';
export const CONTRACT_KEY='pathfolio.sbt.sepolia.contract.v1';
type Injected={request:(args:{method:string;params?:unknown[]})=>Promise<any>;on?:(event:string,fn:(...args:any[])=>void)=>void;removeListener?:(event:string,fn:(...args:any[])=>void)=>void};
export function wallet():Injected {const w=(window as Window&{ethereum?:Injected}).ethereum;if(!w)throw Error('MetaMask가 설치된 브라우저에서 열어 주세요.');return w;}
export const WALLET_WAIT='MetaMask의 응답을 기다리고 있어요. Chrome 오른쪽 위 확장 프로그램(퍼즐) → MetaMask를 열어 잠금을 해제하고 대기 중인 요청을 확인해 주세요. 확인한 뒤 다시 연결할 수 있습니다.';
export function walletRequest<T>(request:Promise<T>,timeout=20000):Promise<T>{return new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error(WALLET_WAIT)),timeout);request.then(value=>{clearTimeout(timer);resolve(value);},error=>{clearTimeout(timer);reject(error);});});}
export async function connectWallet(){const w=wallet();await walletRequest(w.request({method:'eth_requestAccounts'}));return currentWallet();}
export async function currentWallet(){
 const w=wallet();if(Number(await walletRequest(w.request({method:'eth_chainId'})))!==CHAIN_ID)throw Error('지갑은 감지됐지만 Sepolia가 아닙니다. 옆의 ‘Sepolia로 전환’을 누르고 MetaMask에서 확인해 주세요.');
 const accounts=await walletRequest(w.request({method:'eth_accounts'}));if(!Array.isArray(accounts)||!isAddress(accounts[0]))throw Error('연결된 지갑 계정이 없어요. MetaMask 잠금을 해제하고 연결을 승인해 주세요.');
 const provider=new BrowserProvider(w,CHAIN_ID);const signer=await walletRequest(provider.getSigner(accounts[0]));
 return {provider,signer,address:await signer.getAddress()};
}
export async function switchNetwork(){await walletRequest(wallet().request({method:'wallet_switchEthereumChain',params:[{chainId:'0xaa36a7'}]}));}
export async function checkedContract(address:string){if(!isAddress(address))throw Error('올바른 컨트랙트 주소를 입력해 주세요.');const {provider,signer,address:account}=await currentWallet();const code=await provider.getCode(address);if(code==='0x'||keccak256(code)!==keccak256('0x'+artifact.evm.deployedBytecode.object))throw Error('이 주소는 검증된 패스폴리오 SBT 코드와 일치하지 않아요.');return {contract:new Contract(address,artifact.abi,signer),account};}
export async function deployContract(){const {signer}=await currentWallet();return new ContractFactory(artifact.abi,artifact.evm.bytecode.object,signer).deploy();}
export type Proof={version:1;chainId:number;contract:string;recipient:string;salt:string;activity:Activity;commitment:string};
export function commitment(p:Omit<Proof,'commitment'>){const a=p.activity;return keccak256(toUtf8Bytes(JSON.stringify(['pathfolio-self-record-v1',p.chainId,p.contract.toLowerCase(),p.recipient.toLowerCase(),p.salt,a.id,a.title,a.type,a.date,a.org,a.note])));}
export function createProof(activity:Activity,contract:string,recipient:string):Proof {const p={version:1 as const,chainId:CHAIN_ID,contract:getAddress(contract),recipient:getAddress(recipient),salt:hexlify(crypto.getRandomValues(new Uint8Array(32))),activity:{...activity}};return {...p,commitment:commitment(p)};}
export function parseProof(raw:string):Proof {if(raw.length>50000)throw Error('검증 파일은 50KB 이내로 올려 주세요.');const p=JSON.parse(raw);if(p?.version!==1||p.chainId!==CHAIN_ID||!isAddress(p.contract)||!isAddress(p.recipient)||!/^0x[0-9a-f]{64}$/i.test(p.salt)||!p.activity||!['id','title','type','date','org','note'].every(k=>typeof p.activity[k]==='string')||p.commitment!==commitment(p))throw Error('검증 파일이 변경되었거나 형식이 올바르지 않아요.');return p;}
export function downloadProof(p:Proof){const url=URL.createObjectURL(new Blob([JSON.stringify(p,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='pathfolio-proof-'+p.commitment.slice(2,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
export function errorMessage(error:unknown){const e=error as {code?:string|number;message?:string;shortMessage?:string};if(Number(e.code)===-32002)return WALLET_WAIT;if(Number(e.code)===4902)return 'MetaMask에서 테스트 네트워크 표시를 켜고 Sepolia를 선택한 뒤 다시 연결해 주세요.';if(e.code===4001||e.code==='ACTION_REJECTED')return '지갑 요청을 취소했습니다. 다시 시도할 수 있어요.';if(e.code==='INSUFFICIENT_FUNDS')return 'Sepolia 테스트 ETH가 부족합니다. 실제 ETH를 보내지 마세요.';return e.shortMessage?.slice(0,160)||e.message?.slice(0,160)||'처리하지 못했어요. 지갑과 네트워크를 확인해 주세요.';}
