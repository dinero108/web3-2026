import {lazy,Suspense} from 'react';
import {createRoot} from 'react-dom/client';
import AuthGate from './auth-gate';
import Dashboard from './dashboard';
import './globals.css';
const SBTPanel=lazy(()=>import('./sbt-panel'));
const page=new URLSearchParams(location.search).get('page');
createRoot(document.getElementById('root')!).render(<AuthGate signup={page==='signup'}>{page==='contract-deploy'?<main className="sbt-deploy-page"><a href="./?tab=badges">← 패스폴리오 활동 증명</a><Suspense fallback={<p>배포 도구를 불러오는 중…</p>}><SBTPanel activities={[]} deployOnly/></Suspense></main>:<Dashboard/>}</AuthGate>);
