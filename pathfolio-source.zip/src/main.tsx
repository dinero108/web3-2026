import {lazy,Suspense} from 'react';
import {createRoot} from 'react-dom/client';
import AuthGate from './auth-gate';
import SharedActivityPage from './shared-activity';
import Dashboard from './dashboard';
import './globals.css';
const SBTPanel=lazy(()=>import('./sbt-panel'));
const params=new URLSearchParams(location.search);const page=params.get('page');const share=params.get('share');if(share){const meta=document.createElement('meta');meta.name='robots';meta.content='noindex,nofollow';document.head.append(meta);const ref=document.createElement('meta');ref.name='referrer';ref.content='no-referrer';document.head.append(ref);}
createRoot(document.getElementById('root')!).render(share?<SharedActivityPage token={share}/>:<AuthGate signup={page==='signup'}>{page==='contract-deploy'?<main className="sbt-deploy-page"><a href="./?tab=badges">← 패스폴리오 활동 증명</a><Suspense fallback={<p>배포 도구를 불러오는 중…</p>}><SBTPanel activities={[]} deployOnly/></Suspense></main>:<Dashboard/>}</AuthGate>);
