import { createRoot } from 'react-dom/client';
import Dashboard from './dashboard';
import './globals.css';
createRoot(document.getElementById('root')!).render(<Dashboard/>);
