import { createRoot } from 'react-dom/client';
import AuthDialog from './auth-dialog';
import {Leaf,ArrowLeft} from 'lucide-react';
import Dashboard from './dashboard';
import './globals.css';
const signup=new URLSearchParams(location.search).get('page')==='signup';
if(signup)document.title='회원가입 | 패스폴리오';
createRoot(document.getElementById('root')!).render(signup?<div className="auth-page"><header className="auth-page-header"><a href="./" className="brand"><span className="brandmark"><Leaf size={22}/></span>패스폴리오</a><a href="./" className="auth-back"><ArrowLeft size={16}/>홈으로</a></header><main><div className="auth-page-intro"><p className="eyebrow">START YOUR NEXT CHAPTER</p><h1>나의 가능성을 기록하는 첫걸음</h1><p>활동과 진로 탐색을 나만의 계정에서 이어가세요.</p></div><AuthDialog page initialMode="signup" onClose={()=>location.assign('./')} onRecovered={()=>{}}/></main></div>:<Dashboard/>);
