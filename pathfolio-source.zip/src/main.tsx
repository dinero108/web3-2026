import {createRoot} from 'react-dom/client';
import DIDApp from './did-app';
import './globals.css';
createRoot(document.getElementById('root')!).render(<DIDApp/>);
