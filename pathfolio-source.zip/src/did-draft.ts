import {createContext} from 'react';
export const DraftContext=createContext<(dirty:boolean)=>void>(()=>{});
