import {useEffect,useState,type ReactNode} from 'react';
import type {User} from '@supabase/supabase-js';
import {Leaf} from 'lucide-react';
import {authReturn,supabase} from './supabase';
import AuthDialog from './auth-dialog';
import AuthResult from './auth-result';
export default function AuthGate({children,signup=false}:{children:ReactNode;signup?:boolean}){
 const [user,setUser]=useState<User|null>(null),[checked,setChecked]=useState(false),[recovery,setRecovery]=useState(authReturn.kind==='recovery');
 useEffect(()=>{try{localStorage.removeItem('pathfolio.portfolio.v1');}catch{}if(!supabase){setChecked(true);return;}const {data:{subscription}}=supabase.auth.onAuthStateChange((event,session)=>{setUser(session?.user??null);setChecked(true);if(event==='PASSWORD_RECOVERY')setRecovery(true);if(event==='SIGNED_OUT')setRecovery(false);});return()=>subscription.unsubscribe();},[]);
 const allowed=!!user?.email_confirmed_at;
 if(checked&&allowed&&!recovery)return <><AuthResult onLogin={()=>{}}/>{children}</>;
 return <div className="auth-page"><header className="auth-page-header"><a href="./" className="brand"><span className="brandmark"><Leaf size={22}/></span>패스폴리오</a><span className="tag">나만의 비공개 성장 기록</span></header><main>{new URLSearchParams(location.search).get("account")==="deleted"&&<p className="notice" role="status">회원탈퇴가 완료되었습니다. 계정과 활동·첨부파일이 삭제되었습니다.</p>}<div className="auth-page-intro"><p className="eyebrow">MY GROWTH SPACE</p><h1>{recovery?'새 비밀번호를 설정해 주세요':signup?'나의 가능성을 기록하는 첫걸음':'로그인하고 나의 기록을 이어가세요'}</h1><p>활동 기록, 파일 보관, AI 활동 추천과 활동 증명은<br/>회원가입과 이메일 인증을 마친 뒤 이용할 수 있어요.</p></div>{!checked?<p className="auth-loading" role="status">로그인 상태를 확인하고 있어요…</p>:<AuthDialog key={recovery?'recovery':signup?'signup':'login'} page initialMode={signup?'signup':'login'} recovery={recovery} onRecovered={()=>setRecovery(false)} onClose={()=>{}}/>}<AuthResult onLogin={()=>{}}/></main></div>;
}
