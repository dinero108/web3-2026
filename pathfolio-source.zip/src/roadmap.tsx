'use client';
import { useState } from 'react';
import { ArrowRight, Check, LockKeyhole, Plus, Flag } from 'lucide-react';
import { fields, getStages, getUnlockedStage, isJourneyComplete, isStageComplete } from './roadmap-model';
import type { Data } from './portfolio-types';
type Props = { data: Data; save: (next: Data) => Promise<boolean>; busy: boolean; signed: boolean; onRecord: () => void; onPortfolio: () => void };
export default function Roadmap({ data, save, busy, signed, onRecord, onPortfolio }: Props) {
  const [chosenField, setChosenField] = useState('');
  const [view, setView] = useState<number | null>(null);
  const [adding, setAdding] = useState(false);
  const [celebration, setCelebration] = useState('');
  const focus = data.interests.includes(chosenField) ? chosenField : data.interests[0];
  const stages = getStages(focus, data.roadmapRounds);
  const unlocked = getUnlockedStage(stages, data.done);
  const current = view === null ? unlocked : Math.min(view, unlocked);
  const stage = stages[current];
  const completed = stages.reduce((count, s) => count + s.missions.filter(m => data.done.includes(m.id)).length, 0);
  const allComplete = isJourneyComplete(stages, data.done);
  const customCount = (data.roadmapRounds?.[focus] ?? []).length;
  function switchField(field: string) { setChosenField(field); setView(null); setAdding(false); setCelebration(''); }
  async function toggleMission(id: string) {
    if (!stage || busy || !signed) return;
    const nextDone = data.done.includes(id) ? data.done.filter(x => x !== id) : [...data.done, id];
    const newlyComplete = !isStageComplete(stage, data.done) && isStageComplete(stage, nextDone);
    if (await save({ ...data, done: nextDone })) {
      if (newlyComplete) {
        setCelebration(`${stage.title}의 세 미션을 모두 완료했어요! ${current < stages.length - 1 ? '다음 단계가 열렸어요.' : '새로운 도전을 직접 계획해 보세요.'}`);
        setView(null);
      } else { setCelebration(''); }
    }
  }
  return <>
    <section className="card">
      <span className="eyebrow">FIND YOUR DIRECTION</span><h2>어떤 일에 마음이 움직이나요?</h2>
      <p className="muted">최대 3개를 선택하고, 분야별로 나만의 여정을 이어가세요. 분야를 바꿔도 완료 기록은 유지돼요.</p>
      <div className="interests">{fields.map(field => <button disabled={busy || !signed || (!data.interests.includes(field) && data.interests.length >= 3)} key={field} aria-pressed={data.interests.includes(field)} className={data.interests.includes(field) ? 'selected' : ''} onClick={async () => {
        const interests = data.interests.includes(field) ? data.interests.filter(x => x !== field) : [...data.interests, field];
        if (await save({ ...data, interests })) switchField(interests[0]);
      }}>{field}{data.interests.includes(field) && <Check size={17}/>}</button>)}</div>
      <div className="form-note">현재는 관심 분야 기반의 규칙형 추천입니다. AI 종합 분석은 아직 연결되지 않았으며, 적성 진단이나 입시 평가를 대신하지 않습니다.</div>
    </section>
    {stage ? <>
      <section className="card journey-summary">
        <div className="field-tabs" role="group" aria-label="탐색할 관심 분야">{data.interests.map(field => <button key={field} className={field === focus ? 'selected' : ''} aria-pressed={field === focus} onClick={() => switchField(field)}>{field}</button>)}</div>
        <div className="section-title"><div><span className="eyebrow">YOUR GROWTH JOURNEY</span><h3>{focus} 성장 로드맵</h3></div><span className="journey-count">{completed} / {stages.length * 3} 미션 완료</span></div>
        <progress className="journey-progress" value={completed} max={stages.length * 3} aria-label={`${focus} 전체 진행률`}/>
        <div className="stage-tabs" role="group" aria-label="로드맵 단계">{stages.map((item, i) => <button key={item.id} disabled={i > unlocked} aria-pressed={i === current} className={`${i === current ? 'current ' : ''}${isStageComplete(item, data.done) ? 'complete' : ''}`} onClick={() => { setView(i); setAdding(false); }}><span>{isStageComplete(item, data.done) ? <Check size={15}/> : i > unlocked ? <LockKeyhole size={13}/> : String(i + 1).padStart(2, '0')}</span>{item.title}</button>)}</div>
        <p className="muted roadmap-guide">한 단계의 세 미션을 마치면 다음 단계가 자동으로 열려요. 이전 단계의 완료를 취소하면 이후 단계는 다시 잠기며, 이미 완료한 미션 기록은 유지됩니다.</p>
      </section>
      {celebration && <div className="milestone" role="status"><Flag size={20}/><span>{celebration}</span></div>}
      <section className="card roadmap">
        <div className="section-title"><div><span className="eyebrow">STEP {String(current + 1).padStart(2, '0')}</span><h3>{stage.title}</h3></div><span className="journey-count">{stage.missions.filter(m => data.done.includes(m.id)).length} / 3 완료</span></div>
        <p className="muted">{stage.description}</p>
        {stage.missions.map((mission, i) => <div className="step" key={mission.id}><span className="step-number">{String(i + 1).padStart(2, '0')}</span><div className="mission-content"><h4>{mission.title}</h4><p>{mission.hint}</p></div><button disabled={busy || !signed} aria-pressed={data.done.includes(mission.id)} className={data.done.includes(mission.id) ? 'checked' : ''} onClick={() => toggleMission(mission.id)}>{data.done.includes(mission.id) ? '완료 ✓' : '완료 표시'}</button></div>)}
        <div className="roadmap-actions"><button className="record-link" onClick={onRecord}><Plus size={15}/> 이번 단계의 활동 기록하기</button>{current < unlocked && <button className="primary" onClick={() => setView(current + 1)}>다음 단계 보기 <ArrowRight size={15}/></button>}</div>
      </section>
      {allComplete && <section className="card next-chapter"><span className="eyebrow">THIS IS JUST THE BEGINNING</span><h2>완주했어요. 다음은 나만의 도전이에요.</h2><p className="muted">완료한 경험을 포트폴리오로 정리하거나, 새롭게 궁금해진 주제로 다음 세 미션을 직접 설계해 보세요.</p><div className="roadmap-actions"><button className="primary" onClick={() => setAdding(true)} disabled={busy || !signed || customCount >= 30}>다음 도전 만들기 <Plus size={15}/></button><button className="record-link" onClick={onPortfolio}>나의 포트폴리오 보기 <ArrowRight size={15}/></button></div>
        {customCount >= 30 && <p className="form-note">이 분야의 도전 30회를 모두 마쳤어요. 다른 관심 분야를 탐색하거나, 지금까지의 경험을 포트폴리오로 정리해 보세요.</p>}
        {adding && <form className="challenge-form" onSubmit={async event => {
          event.preventDefault(); if (busy || !allComplete || customCount >= 30) return;
          const form = new FormData(event.currentTarget);
          const titles = [0, 1, 2].map(i => String(form.get(`mission-${i}`) ?? '').trim());
          if (titles.some(title => title.length < 3)) { const input = event.currentTarget.querySelector('input'); input?.focus(); return; }
          const rounds = { ...data.roadmapRounds, [focus]: [...(data.roadmapRounds?.[focus] ?? []), titles] };
          if (await save({ ...data, roadmapRounds: rounds })) { setAdding(false); setView(null); setCelebration('나의 새로운 도전이 시작됐어요. 한 걸음씩 실천해 보세요.'); }
        }}><h3>나의 도전 {customCount + 1} 설계하기</h3>{['알아볼 주제와 완료 기준', '직접 실행할 일과 결과물', '돌아보고 정리할 내용'].map((label, i) => <label key={label}>{i + 1}. {label}<input name={`mission-${i}`} required minLength={3} maxLength={150} placeholder={['예: 관심 직무 종사자의 공개 인터뷰 2개 비교하기', '예: 인터뷰에서 배운 방법으로 작은 결과물 만들기', '예: 결과물과 피드백을 한 장의 활동 기록으로 정리하기'][i]}/></label>)}<div className="roadmap-actions"><button className="primary" disabled={busy}>{busy ? '저장 중…' : '이 도전 시작하기'}</button><button type="button" onClick={() => setAdding(false)}>취소</button></div></form>}
      </section>}
    </> : <section className="card empty"><Flag/><h4>관심 분야를 선택하면 첫 여정이 열려요</h4><p>첫 탐색부터 프로젝트와 포트폴리오까지 이어집니다.</p></section>}
  </>;
}
