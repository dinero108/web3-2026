export const fields = ['기술·공학', '디자인·예술', '인문·사회', '생명·환경', '교육·돌봄', '경영·경제'];
export type Mission = { id: string; title: string; hint: string };
export type Stage = { id: string; title: string; description: string; missions: Mission[] };
export type CustomRounds = Record<string, string[][]>;
const curricula: Record<string, string[][]> = {
  '기술·공학': [
    ['생활 속 불편을 하나 찾아 사용자 3명 인터뷰하기', '문제 해결 아이디어를 간단한 앱이나 모형으로 만들기', '제작 과정과 시행착오를 정리하고 피드백 받기'],
    ['관심 직무 2개를 골라 실제 하는 일과 필요한 기술 비교하기', '인터뷰에서 나온 개선 의견 중 하나를 골라 관련 원리 공부하기', '공부한 원리를 작은 실험이나 코드로 확인하고 결과 남기기'],
    ['해결할 문제와 사용자를 정하고 2주 프로젝트 계획 세우기', '핵심 기능 한 가지를 구현한 뒤 사용자에게 사용해 보게 하기', '사용 전후의 차이를 관찰하고 개선한 버전 완성하기'],
    ['문제·설계·구현·검증 과정을 담은 프로젝트 사례 작성하기', '완성한 결과물을 친구나 선생님에게 설명하고 질문 기록하기', '흥미와 어려움을 돌아보고 다음에 배울 기술 한 가지 정하기'],
  ],
  '디자인·예술': [
    ['좋아하는 작품 5개를 모으고 공통점 적기', '학교나 지역의 안내물을 새롭게 디자인하기', '작품 설명과 피드백을 포트폴리오에 기록하기'],
    ['관심 창작 직무 2개를 골라 작업 방식과 표현 도구 비교하기', '좋아하는 작품의 색·구도·표현을 분석해 연습 작품 만들기', '작품을 보여 주고 의도와 다르게 전달된 부분 기록하기'],
    ['전달할 메시지와 관객을 정해 2주 창작 계획 세우기', '서로 다른 시안 2개를 만들고 관객의 반응 비교하기', '피드백을 반영해 최종 작품과 작품 설명 완성하기'],
    ['스케치부터 최종 작품까지 변화 과정을 한 사례로 정리하기', '작은 전시나 발표로 작품을 공유하고 감상 의견 기록하기', '나의 표현 강점과 다음에 연습할 기법 한 가지 정하기'],
  ],
  '인문·사회': [
    ['관심 있는 사회 이슈의 서로 다른 관점 읽기', '관련 분야 종사자에게 물어볼 질문 5개 만들기', '나의 관점을 근거와 함께 글로 정리하기'],
    ['관심 직무 2개를 골라 사회 문제에 접근하는 방식 비교하기', '탐구 질문 하나를 정하고 출처가 다른 자료 3개 검토하기', '자료의 주장·근거·한계를 비교한 탐구 노트 작성하기'],
    ['조사할 대상과 방법을 정해 2주 탐구 계획 세우기', '동의를 받은 인터뷰나 공개 자료 조사로 근거 수집하기', '반대 관점과 조사 한계를 포함한 탐구 보고서 완성하기'],
    ['질문·자료·분석·결론을 담은 탐구 사례 정리하기', '탐구 내용을 발표하고 받은 질문에 근거를 찾아 답하기', '관심이 깊어진 문제와 다음에 탐구할 질문 한 가지 정하기'],
  ],
  '생명·환경': [
    ['주변의 환경 문제를 일주일 관찰하기', '관찰 내용을 표로 정리하고 작은 실험 설계하기', '실험 결과와 한계를 기록한 보고서 만들기'],
    ['관심 직무 2개를 골라 연구 주제와 사용하는 방법 비교하기', '관찰에서 나온 질문 하나를 골라 관련 과학 원리 공부하기', '교사의 지도로 안전한 실험을 설계하거나 공개 데이터 분석하기'],
    ['검증할 가설과 측정 방법을 정해 2주 탐구 계획 세우기', '안전한 관찰이나 공개 데이터 분석을 반복하고 조건 기록하기', '결과를 그래프로 표현하고 가설과 다른 결과도 해석하기'],
    ['질문·방법·결과·한계를 담은 탐구 사례 정리하기', '탐구 결과를 발표하고 개선할 실험 조건에 대한 의견 받기', '관심이 깊어진 주제와 다음 관찰 질문 한 가지 정하기'],
  ],
  '교육·돌봄': [
    ['누군가의 배움을 도운 경험 돌아보기', '이해하기 쉬운 학습 자료를 직접 만들기', '자료를 사용한 사람의 의견을 받아 개선하기'],
    ['관심 직무 2개를 골라 돕는 대상과 필요한 역량 비교하기', '배우는 사람이 어려워한 지점 하나를 골라 원인 살펴보기', '같은 내용을 서로 다른 방식으로 설명하는 자료 2개 만들기'],
    ['학습 목표와 대상을 정해 2주 학습 지원 계획 세우기', '상대의 동의를 받아 자료를 활용하고 이해 과정 관찰하기', '개인정보 없이 관찰 내용을 정리하고 자료 개선하기'],
    ['학습 목표·자료·관찰·개선 과정을 담은 사례 정리하기', '개선 자료를 친구나 선생님에게 설명하고 피드백 받기', '돕는 과정에서 발견한 강점과 다음 학습 주제 정하기'],
  ],
  '경영·경제': [
    ['자주 사용하는 서비스의 고객과 가치 분석하기', '소규모 설문으로 새로운 서비스 아이디어 검증하기', '조사 결과를 바탕으로 한 장의 기획서 만들기'],
    ['관심 직무 2개를 골라 해결하는 문제와 필요한 역량 비교하기', '비슷한 서비스 3개의 고객·가격·가치 제안 비교하기', '설문 결과에서 중요한 가정 하나를 골라 추가로 조사하기'],
    ['해결할 고객 문제와 검증 기준을 정해 2주 프로젝트 계획 세우기', '서비스 모형을 만들고 잠재 사용자에게 피드백 받기', '예상 비용과 제공 가치를 비교해 기획서 개선하기'],
    ['고객 문제·조사·검증·개선을 담은 기획 사례 정리하기', '기획안을 발표하고 근거가 부족한 가정을 보완하기', '흥미를 느낀 업무와 다음에 검증할 아이디어 한 가지 정하기'],
  ],
};
const stageInfo = [
  ['explore', '첫 탐색', '좋아하는 분야를 작게 경험하고 나의 반응을 발견해요.'],
  ['deepen', '심화 탐구', '직무와 원리를 비교하며 더 깊게 알아봐요.'],
  ['project', '프로젝트 실행', '2주 동안 나만의 결과물을 만들고 개선해요.'],
  ['reflect', '포트폴리오 정리', '배운 점을 정리하고 다음 성장 방향을 선택해요.'],
];
const hints = [
  ['관찰한 내용과 질문을 짧게 남겨요.', '완벽한 결과보다 직접 해 본 과정을 남겨요.', '다른 사람의 의견과 나의 생각을 함께 적어요.'],
  ['일의 공통점과 차이점을 표로 비교해 보세요.', '궁금한 점을 하나로 좁히고 참고한 출처를 남겨요.', '새롭게 알게 된 점과 아직 모르는 점을 구분해요.'],
  ['목표·일정·완료 기준을 구체적으로 적어요.', '작은 결과부터 만들고 실제 반응을 살펴요.', '처음과 달라진 점, 개선 이유, 남은 한계를 기록해요.'],
  ['과정과 근거가 드러나도록 정리해요.', '칭찬뿐 아니라 보완할 의견도 함께 남겨요.', '잘한 점·어려웠던 점·다음에 해 볼 일을 적어요.'],
];
export function getStages(field: string, rounds: CustomRounds = {}): Stage[] {
  if (!fields.includes(field)) return [];
  const stages = curricula[field].map((titles, index) => ({
    id: stageInfo[index][0], title: stageInfo[index][1], description: stageInfo[index][2],
    missions: titles.map((title, mission) => ({
      // Keep first-stage IDs compatible with the original completion records.
      id: index === 0 ? field + title : `${field}:${stageInfo[index][0]}:${mission}`,
      title, hint: hints[index][mission],
    })),
  }));
  const extra = rounds[field] ?? [];
  return [...stages, ...extra.map((titles, round) => ({
    id: `challenge-${round}`, title: `나의 도전 ${round + 1}`, description: '직접 정한 목표를 실행하고 경험을 다음 도전으로 이어가요.',
    missions: titles.map((title, mission) => ({ id: `${field}:challenge-${round}:${mission}`, title, hint: ['할 일과 완료 기준을 구체적으로 정해요.', '진행하면서 발견한 점과 결과물을 남겨요.', '과정을 돌아보고 다음에 바꿔 볼 점을 적어요.'][mission] })),
  }))];
}
export function isStageComplete(stage: Stage, done: string[]) { return stage.missions.every(m => done.includes(m.id)); }
export function getUnlockedStage(stages: Stage[], done: string[]) {
  const next = stages.findIndex(s => !isStageComplete(s, done));
  return next < 0 ? Math.max(0, stages.length - 1) : next;
}
export function isJourneyComplete(stages: Stage[], done: string[]) { return stages.length > 0 && stages.every(s => isStageComplete(s, done)); }
export function validCustomRounds(value: unknown): value is CustomRounds {
  if (value === undefined) return true; // Existing portfolios did not have this property.
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  return Object.entries(value).every(([field, rounds]) => fields.includes(field) && Array.isArray(rounds) && rounds.length <= 30 && rounds.every(round => Array.isArray(round) && round.length === 3 && round.every(title => typeof title === 'string' && title.trim().length >= 3 && title.length <= 150)));
}
