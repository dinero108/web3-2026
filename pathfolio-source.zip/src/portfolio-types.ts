import type { CustomRounds } from './roadmap-model';
export type Activity = { id: string; title: string; type: string; date: string; org: string; note: string };
export type Data = { name: string; interests: string[]; activities: Activity[]; done: string[]; roadmapRounds?: CustomRounds };
