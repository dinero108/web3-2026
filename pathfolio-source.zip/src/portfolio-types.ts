import type { CustomRounds } from './roadmap-model';
export type Attachment = { path: string; name: string; size: number; type: string };
export type Activity = { id: string; title: string; type: string; date: string; org: string; note: string; attachments?: Attachment[] };
export type Data = { name: string; interests: string[]; activities: Activity[]; done: string[]; roadmapRounds?: CustomRounds };
