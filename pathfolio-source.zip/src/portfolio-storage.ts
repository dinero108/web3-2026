import {validAttachments} from './attachment-rules';
import type { Data } from './portfolio-types';
import { fields, validCustomRounds } from './roadmap-model';
export const BROWSER_MODE = process.env.NEXT_PUBLIC_PORTFOLIO_MODE === 'browser';
export const MAX_BACKUP_BYTES=1000000;
const STORAGE_KEY = 'pathfolio.portfolio.v1';
export function isPortfolio(value: unknown): value is Data {
  if (!value || typeof value !== 'object') return false;
  const data = value as Data;
  return typeof data.name === 'string' && data.name.length <= 60
    && Array.isArray(data.interests) && data.interests.length <= 3 && data.interests.every(s => fields.includes(s))
    && Array.isArray(data.done) && data.done.length <= 1000 && data.done.every(s => typeof s === 'string' && s.length <= 250)
    && validCustomRounds(data.roadmapRounds)
    && Array.isArray(data.activities) && data.activities.length <= 200
    && new Set(data.activities.map(a=>a?.id)).size===data.activities.length && data.activities.every(a => a
      && typeof a.id === 'string' && a.id.trim().length > 0 && a.id.length <= 150
      && typeof a.title === 'string' && a.title.trim().length > 0 && a.title.length <= 150
      && typeof a.note === 'string' && a.note.length <= 3000
      && typeof a.date === 'string' && a.date.length <= 30
      && typeof a.type === 'string' && a.type.length <= 50
      && validAttachments(a.attachments)
      && typeof a.org === 'string' && a.org.length <= 150);
}
export function parsePortfolio(raw: string): Data {
  if (new TextEncoder().encode(raw).length > MAX_BACKUP_BYTES) throw new Error('기록 파일은 1MB 이내로 올려 주세요.');
  const data: unknown = JSON.parse(raw);
  if (!isPortfolio(data)) throw new Error('패스폴리오 기록 파일인지 확인해 주세요.');
  if(JSON.stringify(data).length>100000)throw new Error('계정에 저장할 수 있는 기록 용량을 초과했어요.');
  return data;
}
export function loadBrowserPortfolio(): Data | null {
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw === null ? null : parsePortfolio(raw);
}
export function saveBrowserPortfolio(data: Data) {
  if (!isPortfolio(data) || JSON.stringify(data).length > 100000) throw new Error('기록의 형식 또는 저장 용량을 확인해 주세요.');
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
export function deleteBrowserPortfolio() { localStorage.removeItem(STORAGE_KEY); }
