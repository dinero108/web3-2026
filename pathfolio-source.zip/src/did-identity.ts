import {getAddress,hexlify,randomBytes,toUtf8Bytes,verifyMessage} from 'ethers';
import {addressFor,didFor} from './did-vault';
export type WalletProvider={request:(args:{method:string;params?:unknown[]})=>Promise<unknown>;on?:(name:string,callback:(...args:unknown[])=>void)=>void;removeListener?:(name:string,callback:(...args:unknown[])=>void)=>void};
export function provider():WalletProvider{const w=(window as unknown as {ethereum?:WalletProvider}).ethereum;if(!w)throw Error('MetaMask 확장 프로그램이 설치된 Chrome에서 열어 주세요. 모바일에서는 MetaMask 앱의 브라우저로 접속해 주세요.');return w;}
async function request(w:WalletProvider,method:string,params?:unknown[]){let timer:ReturnType<typeof setTimeout>;try{return await Promise.race([w.request({method,params}),new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(Error('지갑 응답을 기다리는 시간이 지났습니다. MetaMask의 대기 요청을 확인한 뒤 다시 시도해 주세요.')),60000);})]);}finally{clearTimeout(timer!);}}
export function challenge(address:string,chain:number,domain:string,uri:string,nonce:string,issuedAt:string){return `${domain} wants you to sign in with your Ethereum account:\n${getAddress(address)}\n\nUnlock your local Pathfolio vault. No transaction or gas fee.\n\nURI: ${uri}\nVersion: 1\nChain ID: ${chain}\nNonce: ${nonce}\nIssued At: ${issuedAt}\nExpiration Time: ${new Date(Date.parse(issuedAt)+5*60_000).toISOString()}`;}
export function verifyChallenge(message:string,signature:string,address:string,issuedAt:string){const age=Date.now()-Date.parse(issuedAt);if(!Number.isFinite(age)||age<0||age>5*60_000||getAddress(verifyMessage(message,signature))!==getAddress(address))throw Error('지갑 서명 확인에 실패했습니다. 다시 연결해 주세요.');}
export async function identify(valid:()=>boolean){
 const w=provider();const accounts=await request(w,'eth_requestAccounts') as string[];const address=getAddress(accounts[0]);const chain=Number(await request(w,'eth_chainId'));if(!Number.isSafeInteger(chain)||chain<1)throw Error('지갑 네트워크를 확인해 주세요.');
 const issuedAt=new Date().toISOString();const message=challenge(address,chain,location.host,location.origin+location.pathname,hexlify(randomBytes(16)).slice(2),issuedAt);
 if(!valid())throw Error('지갑이 변경되었습니다. 다시 연결해 주세요.');
 const signature=await request(w,'personal_sign',[hexlify(toUtf8Bytes(message)),address]) as string;
 verifyChallenge(message,signature,address,issuedAt);
 const now=await request(w,'eth_accounts') as string[];const nowChain=Number(await request(w,'eth_chainId'));
 if(!valid()||nowChain!==chain||!now[0]||getAddress(now[0])!==address)throw Error('지갑 또는 네트워크가 변경되었습니다. 다시 연결해 주세요.');
 return didFor(address);
}
export async function signFor(did:string,message:string){const w=provider();const before=await request(w,'eth_accounts') as string[];const address=addressFor(did);if(!before[0]||getAddress(before[0])!==address)throw Error('보관함을 연 지갑으로 연결해 주세요.');const sig=await request(w,'personal_sign',[hexlify(toUtf8Bytes(message)),address]) as string;const after=await request(w,'eth_accounts') as string[];if(!after[0]||getAddress(after[0])!==address||getAddress(verifyMessage(message,sig))!==address)throw Error('지갑 서명이 일치하지 않습니다.');return sig;}
export function walletError(e:unknown){if((e as {code?:number})?.code===4001)return '지갑 요청을 취소했어요.';if((e as {code?:number})?.code===-32002)return 'MetaMask에 대기 중인 요청이 있습니다. 여우 아이콘을 열어 확인해 주세요.';return e instanceof Error?e.message:'처리하지 못했습니다. 다시 시도해 주세요.';}
