import {useEffect,useState} from 'react';
import {Eye,EyeOff} from 'lucide-react';
import {supabase,redirectUrl} from './supabase';
import {PASSWORD_RULE,validPassword} from './auth-feedback';
type Mode='login'|'signup'|'reset'|'verify';
export default function AuthDialog({onClose,recovery=false,onRecovered,page=false,initialMode='login'}:{onClose:()=>void;recovery?:boolean;onRecovered:()=>void;page?:boolean;initialMode?:Mode}) {
 const [mode,setMode]=useState<Mode>(initialMode);
 const [busy,setBusy]=useState(false),[message,setMessage]=useState(''),[email,setEmail]=useState('');
 const [password,setPassword]=useState(''),[confirmation,setConfirmation]=useState('');
 const [showPassword,setShowPassword]=useState(false),[showConfirmation,setShowConfirmation]=useState(false);
 const [retryAt,setRetryAt]=useState(0),[seconds,setSeconds]=useState(0);
 useEffect(()=>{if(!retryAt)return;const update=()=>setSeconds(Math.max(0,Math.ceil((retryAt-Date.now())/1000)));update();const timer=setInterval(update,1000);return()=>clearInterval(timer);},[retryAt]);
 const newPassword=recovery||mode==='signup';
 const title=recovery?'새 비밀번호 설정':mode==='signup'?'회원가입':mode==='reset'?'비밀번호 찾기':mode==='verify'?'이메일 인증':'로그인';
 function changeMode(next:Mode){if(next==='signup'&&!page){location.assign('?page=signup');return;}setShowPassword(false);setShowConfirmation(false);setMode(next);setMessage('');setPassword('');setConfirmation('');}
 function failed(error:unknown){
  const code=(error as {code?:string}).code;
  if(code==='email_not_confirmed'){setMessage('아직 이메일 인증이 완료되지 않았어요. 인증 메일 다시 받기를 눌러 주세요.');}
  else if(code==='otp_expired')setMessage('인증번호가 만료되었거나 올바르지 않아요. 새 메일을 받아 가장 최근 인증번호를 입력해 주세요.');
  else if(code==='weak_password')setMessage(PASSWORD_RULE);
  else if(code==='over_email_send_rate_limit'||code==='over_request_rate_limit'){setMessage('요청이 많아요. 잠시 기다린 뒤 다시 시도해 주세요.');setRetryAt(Date.now()+60000);}
  else if(code==='invalid_credentials')setMessage('이메일 또는 비밀번호가 올바르지 않아요. 다시 확인해 주세요.');
  else setMessage('요청을 처리하지 못했어요. 연결 상태를 확인하고 다시 시도해 주세요.');
 }
 async function resend(){
  if(!supabase||busy||seconds>0)return;
  if(!email.trim()||! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())){setMessage('먼저 가입한 이메일을 입력해 주세요.');return;}
  setBusy(true);setMessage('');
  try{const {error}=await supabase.auth.resend({type:'signup',email:email.trim(),options:{emailRedirectTo:redirectUrl()}});if(error)throw error;changeMode('verify');setMessage('인증 메일을 요청했어요. 가장 최근 메일의 링크 또는 인증번호를 사용해 주세요.');setRetryAt(Date.now()+60000);}catch(error){failed(error);}finally{setBusy(false);}
 }
 return <div className={page?"auth-page-body":"overlay"}><section className="modal auth-modal" role={page?"region":"dialog"} aria-modal={page?undefined:true} aria-labelledby="auth-title"><div className="section-title"><h2 id="auth-title">{title}</h2>{!page&&<button aria-label="닫기" disabled={busy} onClick={onClose}>×</button>}</div>
 {!supabase?<p role="status">계정 로그인 연결을 준비하고 있어요. 지금은 게스트로 기록할 수 있습니다.</p>:<>
 <p className="muted">{mode==='verify'?'가장 최근에 받은 인증 메일의 링크를 누르거나 인증번호를 입력해 주세요. 다른 브라우저에서 인증했다면 이 화면에서 로그인해 주세요.':'내 활동과 로드맵을 계정에 저장하고 이어가세요.'}</p>
 <form onSubmit={async e=>{e.preventDefault();if(busy||!supabase)return;
 if(newPassword&&!validPassword(password)){setMessage(PASSWORD_RULE);return;}
 if(newPassword&&password!==confirmation){setMessage('비밀번호가 일치하지 않아요. 다시 확인해 주세요.');return;}
 const form=e.currentTarget;const token=String(new FormData(form).get('token')??'').trim();setBusy(true);setMessage('');
 try{
 if(recovery){const {error}=await supabase.auth.updateUser({password});if(error)throw error;onRecovered();onClose();}
 else if(mode==='login'){const {error}=await supabase.auth.signInWithPassword({email:email.trim(),password});if(error)throw error;onClose();}
 else if(mode==='signup'){const {data,error}=await supabase.auth.signUp({email:email.trim(),password,options:{emailRedirectTo:redirectUrl()}});if(error)throw error;if(data.session)onClose();else{changeMode('verify');setMessage('가입 안내 메일을 확인해 주세요. 이미 가입했다면 로그인해 주세요. 스팸함도 확인해 주세요.');setRetryAt(Date.now()+60000);}}
 else if(mode==='verify'){const {error}=await supabase.auth.verifyOtp({email:email.trim(),token,type:'signup'});if(error)throw error;onClose();}
 else{const {error}=await supabase.auth.resetPasswordForEmail(email.trim(),{redirectTo:redirectUrl()});if(error)throw error;setMessage('가입한 이메일이라면 재설정 안내가 발송됩니다. 가장 최근 메일을 확인해 주세요.');}
 }catch(error){failed(error);}finally{setBusy(false);}}}>
 {!recovery&&<label>이메일<input autoFocus type="email" name="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} required maxLength={254} disabled={busy}/></label>}
 {(newPassword||mode==='login')&&<label>비밀번호<span className="password-input"><input type={showPassword?"text":"password"} name="password" aria-label="비밀번호" autoComplete={newPassword?'new-password':'current-password'} value={password} onChange={e=>setPassword(e.target.value)} required minLength={newPassword?10:1} maxLength={128} disabled={busy} aria-describedby={newPassword?'password-rules':undefined}/><button type="button" className="password-toggle" aria-label={showPassword?'비밀번호 숨기기':'비밀번호 보기'} aria-pressed={showPassword} disabled={busy} onClick={()=>setShowPassword(v=>!v)}>{showPassword?<EyeOff size={20}/>:<Eye size={20}/>}</button></span>{newPassword&&<small id="password-rules">{PASSWORD_RULE}</small>}</label>}
 {newPassword&&<label>비밀번호 확인<span className="password-input"><input type={showConfirmation?"text":"password"} name="confirmation" aria-label="비밀번호 확인" autoComplete="new-password" value={confirmation} onChange={e=>setConfirmation(e.target.value)} required minLength={10} maxLength={128} disabled={busy} aria-invalid={!!confirmation&&password!==confirmation}/><button type="button" className="password-toggle" aria-label={showConfirmation?'비밀번호 확인 숨기기':'비밀번호 확인 보기'} aria-pressed={showConfirmation} disabled={busy} onClick={()=>setShowConfirmation(v=>!v)}>{showConfirmation?<EyeOff size={20}/>:<Eye size={20}/>}</button></span>{confirmation&&<small>{password===confirmation?'비밀번호가 일치해요.':'비밀번호가 일치하지 않아요.'}</small>}</label>}
 {mode==='verify'&&!recovery&&<label>인증번호<input name="token" aria-label="인증번호" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" minLength={6} maxLength={6} required disabled={busy}/><small>가장 최근 메일에 적힌 6자리 숫자를 입력해 주세요.</small></label>}
 {message&&<p role="status">{message}</p>}<button className="primary wide" disabled={busy}>{busy?'처리 중…':mode==='verify'&&!recovery?'인증하고 시작하기':title}</button></form>
 {!recovery&&<div className="auth-links">{(['login','signup','reset','verify'] as const).filter(m=>m!==mode).map(m=><button key={m} disabled={busy} onClick={()=>changeMode(m)}>{m==='login'?'로그인':m==='signup'?'회원가입':m==='reset'?'비밀번호 찾기':'인증번호 입력'}</button>)}{(mode==='verify'||mode==='login')&&<button disabled={busy||seconds>0} onClick={()=>void resend()}>{seconds>0?`인증 메일 재발송 (${seconds}초)`:'인증 메일 다시 받기'}</button>}</div>}
 </>}</section></div>;
}
