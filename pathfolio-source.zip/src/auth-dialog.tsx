import {useState} from 'react';
import {supabase,redirectUrl} from './supabase';
export default function AuthDialog({onClose,recovery=false,onRecovered}:{onClose:()=>void;recovery?:boolean;onRecovered:()=>void}) {
 const [mode,setMode]=useState<'login'|'signup'|'reset'>( 'login');
 const [busy,setBusy]=useState(false);const [message,setMessage]=useState('');
 const title=recovery?'새 비밀번호 설정':mode==='signup'?'회원가입':mode==='reset'?'비밀번호 찾기':'로그인';
 return <div className="overlay"><section className="modal auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-title"><div className="section-title"><h2 id="auth-title">{title}</h2><button aria-label="닫기" disabled={busy} onClick={onClose}>×</button></div>
 {!supabase?<p role="status">계정 로그인 연결을 준비하고 있어요. 지금은 게스트로 기록할 수 있으며 기존 기록은 유지됩니다.</p>:<>
 <p className="muted">내 활동과 로드맵을 계정에 저장하고 이어가세요.</p>{mode==="signup"&&<p className="form-note">가입 후 받은 인증 메일의 링크를 눌러 주세요. 메일이 보이지 않으면 스팸함도 확인해 주세요.</p>}
 <form onSubmit={async e=>{e.preventDefault();if(busy||!supabase)return;setBusy(true);setMessage('');const f=new FormData(e.currentTarget);const email=String(f.get('email')??'').trim();const password=String(f.get('password')??'');try{
 if(recovery){const {error}=await supabase.auth.updateUser({password});if(error)throw error;onRecovered();onClose();}
 else if(mode==='login'){const {error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;onClose();}
 else if(mode==='signup'){const {data,error}=await supabase.auth.signUp({email,password,options:{emailRedirectTo:redirectUrl()}});if(error)throw error;if(data.session)onClose();else setMessage('가입 안내 메일을 확인해 주세요. 이미 가입한 이메일이라면 로그인하거나 비밀번호를 재설정해 주세요.');}
 else{const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:redirectUrl()});if(error)throw error;setMessage('가입한 이메일이라면 재설정 안내가 발송됩니다. 메일함을 확인해 주세요.');}
 }catch(error){const code=(error as {code?:string}).code;if(code==='email_address_not_authorized')setMessage('인증 메일 서비스 연결 전에는 운영자 이메일로만 가입할 수 있어요.');else if(code==='over_email_send_rate_limit')setMessage('메일 발송 한도에 도달했어요. 잠시 후 다시 시도해 주세요.');else setMessage(mode==='login'?'이메일·비밀번호와 이메일 인증 여부를 확인해 주세요.':'요청을 처리하지 못했어요. 잠시 후 다시 시도해 주세요.');}finally{setBusy(false);}}}>
 {!recovery&&<label>이메일<input autoFocus type="email" name="email" autoComplete="email" required maxLength={254} disabled={busy}/></label>}
 {(recovery||mode!=='reset')&&<label>비밀번호<input type="password" name="password" autoComplete={recovery||mode==='signup'?'new-password':'current-password'} required minLength={mode==='login'&&!recovery?1:8} maxLength={128} disabled={busy}/>{(recovery||mode==='signup')&&<small>8자 이상 입력해 주세요.</small>}</label>}
 {message&&<p role="status">{message}</p>}<button className="primary wide" disabled={busy}>{busy?'처리 중…':title}</button></form>
 {!recovery&&<div className="auth-links">{(['login','signup','reset'] as const).filter(m=>m!==mode).map(m=><button key={m} disabled={busy} onClick={()=>{setMode(m);setMessage('');}}>{m==='login'?'로그인':m==='signup'?'회원가입':'비밀번호 찾기'}</button>)}</div>}
 </> }</section></div>;
}
