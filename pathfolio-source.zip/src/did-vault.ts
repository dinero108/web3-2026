import {validateRecords,type SavedAI} from './did-ai-protocol';
import {validateResult} from './did-ai-policy';
import {getAddress, isAddress, verifyMessage, keccak256, toUtf8Bytes} from 'ethers';
import type {Activity} from './portfolio-types';
import {FILE_TYPES, MAX_FILE_SIZE} from './attachment-rules';

export const MAX_BACKUP=100*1024*1024;
export const MAX_TOTAL=50*1024*1024;
const iterations=600_000;
export type LocalFile={id:string;name:string;size:number;type:string;content:string};
export type LocalActivity=Omit<Activity,'attachments'>&{files:LocalFile[]};
export type VaultData={name:string;activities:LocalActivity[];aiRecommendation?:SavedAI};
export type Envelope={format:'pathfolio-vault';version:1;did:string;salt:string;iv:string;iterations:number;ciphertext:string;revision:number};
export type Session={envelope:Envelope;key:CryptoKey;data:VaultData};
export function didFor(address:string){return `did:pkh:eip155:1:${getAddress(address)}`;}
export function addressFor(did:string){const prefix='did:pkh:eip155:1:';if(!did.startsWith(prefix)||!isAddress(did.slice(prefix.length)))throw Error('지원하지 않는 DID입니다.');return getAddress(did.slice(prefix.length));}
export function base64(bytes:Uint8Array){let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);}
export function unbase64(value:string){if(value.length%4!==0||/[^A-Za-z0-9+/=]/.test(value))throw Error('파일의 인코딩이 올바르지 않습니다.');let decoded:string;try{decoded=atob(value);}catch{throw Error('파일의 인코딩이 올바르지 않습니다.');}const bytes=new Uint8Array(decoded.length);for(let i=0;i<decoded.length;i++)bytes[i]=decoded.charCodeAt(i);return bytes;}
const text=(value:unknown,max:number)=>typeof value==='string'&&value.length<=max;
export function validateData(value:unknown):asserts value is VaultData{
 const d=value as VaultData;let total=0;
 if(!d||!text(d.name,60)||!Array.isArray(d.activities)||d.activities.length>200)throw Error('보관함 형식이 올바르지 않습니다.');
 if(d.aiRecommendation){const ai=d.aiRecommendation;if(!ai||typeof ai.createdAt!=='string'||!Number.isFinite(Date.parse(ai.createdAt)))throw Error('추천 저장 형식이 올바르지 않습니다.');validateResult(ai.result,validateRecords(ai.records));}
 const ids=new Set<string>();
 for(const a of d.activities){
  if(!a||!text(a.id,150)||!a.id||ids.has(a.id)||!text(a.title,150)||!a.title.trim()||!text(a.type,50)||!text(a.date,30)||!text(a.org,150)||!text(a.note,3000)||!Array.isArray(a.files)||a.files.length>5)throw Error('활동 기록의 형식 또는 개수 제한을 확인해 주세요.');
  ids.add(a.id);const fileIds=new Set<string>();
  for(const f of a.files){
   if(!f||!text(f.id,100)||!f.id||fileIds.has(f.id)||!text(f.name,180)||!Object.hasOwn(FILE_TYPES,f.name.split('.').pop()!.toLowerCase())||!text(f.type,150)||!Number.isInteger(f.size)||f.size<=0||f.size>MAX_FILE_SIZE||typeof f.content!=='string'||f.content.length>Math.ceil(MAX_FILE_SIZE/3)*4||unbase64(f.content).byteLength!==f.size)throw Error('첨부파일이 손상되었거나 지원하지 않는 형식입니다.');
   fileIds.add(f.id);total+=f.size;
  }
 }
 if(total>MAX_TOTAL)throw Error('이 보관함에는 첨부파일을 합계 50MB까지 저장할 수 있어요. 먼저 백업하고 파일을 정리해 주세요.');
}
export function validateEnvelope(e:unknown):asserts e is Envelope{
 const v=e as Envelope;
 if(!v||v.format!=='pathfolio-vault'||v.version!==1||typeof v.did!=='string'||v.iterations!==iterations||!Number.isSafeInteger(v.revision)||v.revision<1||!text(v.salt,24)||!text(v.iv,16)||!text(v.ciphertext,MAX_BACKUP))throw Error('지원하는 패스폴리오 암호화 백업 파일이 아닙니다.');
 addressFor(v.did);
 if(unbase64(v.salt).length!==16||unbase64(v.iv).length!==12||unbase64(v.ciphertext).length<16)throw Error('암호화 백업이 손상되었습니다.');
}
function aad(e:Envelope){return new TextEncoder().encode(JSON.stringify([e.format,e.version,e.did,e.salt,e.iterations,e.revision]));}
async function keyFor(password:string,salt:string){
 const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveKey']);
 return crypto.subtle.deriveKey({name:'PBKDF2',salt:unbase64(salt),iterations,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
export async function seal(session:Session,data:VaultData):Promise<Session>{
 validateData(data);const e={...session.envelope,revision:session.envelope.revision+1,iv:base64(crypto.getRandomValues(new Uint8Array(12)))};
 const bytes=new TextEncoder().encode(JSON.stringify(data));
 e.ciphertext=base64(new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:unbase64(e.iv),additionalData:aad(e)},session.key,bytes)));
 return {key:session.key,data,envelope:e};
}
export async function createVault(did:string,password:string,name:string){
 addressFor(did);if(password.length<12)throw Error('보관함 비밀번호를 12자 이상 입력해 주세요.');
 const salt=base64(crypto.getRandomValues(new Uint8Array(16)));const key=await keyFor(password,salt);
 return seal({key,data:{name,activities:[]},envelope:{format:'pathfolio-vault',version:1,did,salt,iv:'',ciphertext:'',iterations,revision:0}},{name,activities:[]});
}
export async function unlockVault(envelope:Envelope,password:string,did:string):Promise<Session>{
 validateEnvelope(envelope);if(envelope.did!==did)throw Error('이 백업을 만든 지갑으로 연결해 주세요.');
 const key=await keyFor(password,envelope.salt);let plain:ArrayBuffer;
 try{plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:unbase64(envelope.iv),additionalData:aad(envelope)},key,unbase64(envelope.ciphertext));}catch{throw Error('비밀번호가 다르거나 백업 파일이 손상되었습니다.');}
 const data:unknown=JSON.parse(new TextDecoder().decode(plain));validateData(data);return {envelope,key,data};
}
async function database(){return new Promise<IDBDatabase>((resolve,reject)=>{const r=indexedDB.open('pathfolio-did-vault',1);r.onupgradeneeded=()=>r.result.createObjectStore('vaults',{keyPath:'did'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(Error('이 브라우저에서 기기 저장소를 열 수 없습니다.'));});}
export async function readVault(did:string):Promise<Envelope|undefined>{const db=await database();try{return await new Promise((resolve,reject)=>{const r=db.transaction('vaults').objectStore('vaults').get(did);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}finally{db.close();}}
// Compare the complete previous ciphertext within one transaction, not just a timestamp.
export async function writeVault(next:Envelope,previous?:Envelope){validateEnvelope(next);const db=await database();try{await new Promise<void>((resolve,reject)=>{const tx=db.transaction('vaults','readwrite');const store=tx.objectStore('vaults');let conflict=false;const r=store.get(next.did);r.onsuccess=()=>{const current=r.result as Envelope|undefined;if(current?.ciphertext!==previous?.ciphertext){conflict=true;tx.abort();return;}store.put(next);};tx.oncomplete=()=>resolve();tx.onabort=()=>reject(Error(conflict?'다른 탭에서 보관함이 변경되었습니다. 현재 입력을 따로 복사한 뒤 잠그고 다시 열어 주세요.':'저장하지 못했습니다. 기기 여유 공간과 브라우저 저장 설정을 확인해 주세요.'));tx.onerror=()=>{};});}finally{db.close();}}
export async function deleteVault(previous:Envelope){const db=await database();try{await new Promise<void>((resolve,reject)=>{const tx=db.transaction('vaults','readwrite');const store=tx.objectStore('vaults');const r=store.get(previous.did);r.onsuccess=()=>{if(r.result?.ciphertext!==previous.ciphertext){tx.abort();return;}store.delete(previous.did);};tx.oncomplete=()=>resolve();tx.onabort=()=>reject(Error('보관함이 변경되었습니다. 다시 열어 확인해 주세요.'));});}finally{db.close();}}
export function download(name:string,body:BlobPart,type='application/json'){const url=URL.createObjectURL(new Blob([body],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
export function downloadLocalFile(file:LocalFile){download(file.name,unbase64(file.content),'application/octet-stream');}

export type SignedRecord={format:'pathfolio-signed-record';version:1;did:string;createdAt:string;activity:LocalActivity;signature:string};
export function recordMessage(record:Omit<SignedRecord,'signature'>){const canonical=JSON.stringify({format:record.format,version:record.version,did:record.did,createdAt:record.createdAt,activity:{id:record.activity.id,title:record.activity.title,type:record.activity.type,date:record.activity.date,org:record.activity.org,note:record.activity.note,files:record.activity.files.map(f=>({id:f.id,name:f.name,size:f.size,type:f.type,content:f.content}))}});return `Pathfolio signed activity v1\nDID: ${record.did}\nCreated: ${record.createdAt}\nContent hash: ${keccak256(toUtf8Bytes(canonical))}\nSelf-authored record, not an institutional credential. No transaction.`;}
export function verifyRecord(value:unknown):SignedRecord{
 const p=value as SignedRecord;if(!p||p.format!=='pathfolio-signed-record'||p.version!==1||typeof p.did!=='string'||!text(p.createdAt,40)||!Number.isFinite(Date.parse(p.createdAt))||!text(p.signature,200))throw Error('지원하는 서명 기록 파일이 아닙니다.');
 validateData({name:'',activities:[p.activity]});
 if(getAddress(verifyMessage(recordMessage(p),p.signature))!==addressFor(p.did))throw Error('작성자 서명이 일치하지 않습니다. 변조된 기록일 수 있어요.');
 return p;
}
