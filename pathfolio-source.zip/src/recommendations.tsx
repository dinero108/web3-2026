import {useEffect,useRef,useState} from 'react';
import {Sparkles,ArrowRight,BookOpen} from 'lucide-react';
import {supabase} from './supabase';
import type {Activity} from './portfolio-types';
import './recommendations.css';
type Suggestion={title:string;reason:string;activityIds:string[];nextActivity:string;steps:string[];reflection:string};
type Analysis={summary:string;recommendations:Suggestion[];caution:string;createdAt:string;count:number};
export default function Recommendations({activities,onRecord,onOpen}:{activities:Activity[];onRecord:()=>void;onOpen:(id:string)=>void}){
 const [result,setResult]=useState<Analysis|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState(''),[consent,setConsent]=useState(false);
 const generation=useRef(0),lock=useRef(false);
 const fingerprint=JSON.stringify(activities.map(({id,title,type,date,note})=>({id,title,type,date,note})));
 useEffect(()=>{generation.current++;setResult(null);setError('');setBusy(false);lock.current=false;return()=>{generation.current++;};},[fingerprint]);
 async function analyze(){
  if(lock.current||!consent||!activities.length||!supabase)return;
  lock.current=true;setBusy(true);setError('');const request=++generation.current;
  try{const {data,error}=await supabase.functions.invoke('activity-recommendations',{body:{consent:true}});
   if(request!==generation.current)return;
   if(error){let message='분석 요청을 완료하지 못했어요. 잠시 후 다시 시도해 주세요.';try{const body=await error.context?.json();if(body?.error)message=body.error;}catch{}throw Error(message);}
   if(!data?.recommendations)throw Error('추천 결과를 읽지 못했어요. 다시 시도해 주세요.');setResult(data);
  }catch(e){if(request===generation.current)setError(e instanceof Error?e.message:'분석에 실패했어요.');}
  finally{if(request===generation.current){lock.current=false;setBusy(false);}}
 }
 return <div className="recommendations"><section className="card recommendation-intro"><span className="eyebrow"><Sparkles size={16}/> MY EXPERIENCE, NEXT POSSIBILITY</span><h2>쌓아온 경험에서<br/>다음 관심사를 발견해요.</h2><p>정해진 미션 대신, 내가 작성한 활동과 배운 점을 AI가 읽고<br className="desktop-break"/> 이어서 탐색해 볼 분야와 구체적인 활동을 제안해요.</p><div className="analysis-flow"><span>01 · 나의 기록 읽기</span><ArrowRight size={16}/><span>02 · 관심 주제 발견</span><ArrowRight size={16}/><span>03 · 다음 경험 추천</span></div></section>
 {!activities.length?<section className="card empty"><BookOpen/><h3>추천의 시작은 나의 첫 기록이에요</h3><p>했던 일, 맡은 역할, 재미있었던 점과 배운 점을 남겨주세요.</p><button className="primary" onClick={onRecord}>첫 활동 기록하기</button></section>:<section className="card"><div className="section-title"><h3>분석할 활동 <span className="count">{activities.length}</span></h3><span className="tag neutral">나만 볼 수 있는 추천</span></div><p>최근 활동 최대 30개를 읽어요. 각 기록의 본문은 최대 1,500자까지 반영됩니다.</p><details><summary>어떤 기록이 사용되나요?</summary><ul>{[...activities].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,30).map(a=><li key={a.id}><button className="activity-title-link" onClick={()=>onOpen(a.id)}>{a.title}</button> · {a.date}</li>)}</ul></details><label className="analysis-consent"><input type="checkbox" checked={consent} disabled={busy} onChange={e=>setConsent(e.target.checked)}/><span>활동 제목·유형·날짜·본문을 OpenAI에 전송해 분석하는 데 동의합니다. 첨부파일과 계정 정보는 전송하지 않습니다.</span></label><button className="primary" disabled={busy||!consent} onClick={()=>void analyze()}><Sparkles size={17}/>{busy?'기록을 읽고 추천을 만들고 있어요…':result?'현재 기록으로 다시 확인':'내 기록으로 AI 추천 받기'}</button><p className="form-note">같은 기록의 결과는 재사용하며, 새로운 분석은 하루 최대 5회 가능합니다. 기록을 추가하거나 수정한 뒤 다시 추천받아 보세요.</p>{error&&<p className="analysis-error" role="alert">{error}</p>}<span role="status" className="muted">{busy?'잠시만 기다려 주세요. 분석에는 최대 1분 정도 걸릴 수 있어요.':''}</span></section>}
 {result&&<><section className="card analysis-summary"><span className="eyebrow">YOUR STORY SO FAR</span><h3>기록에서 발견한 흐름</h3><p className="preserve">{result.summary}</p><small>{new Date(result.createdAt).toLocaleString('ko-KR')} · 활동 {result.count}개 분석</small></section><div className="recommendation-grid">{result.recommendations.map((r,i)=><article className="card recommendation-card" key={i}><span className="recommendation-number">0{i+1}</span><h3>{r.title}</h3><p>{r.reason}</p><div className="evidence"><b>이 기록을 바탕으로 추천했어요</b>{r.activityIds.map(id=>{const a=activities.find(a=>a.id===id);return a?<button key={id} onClick={()=>onOpen(id)}><BookOpen size={14}/>{a.title} ↗</button>:null;})}</div><h4>직접 해볼 활동</h4><p>{r.nextActivity}</p><ol>{r.steps.map((step,j)=><li key={j}>{step}</li>)}</ol><div className="reflection"><b>활동 후 돌아볼 질문</b><p>{r.reflection}</p></div><button onClick={onRecord}>새로운 경험 기록하기 <ArrowRight size={15}/></button></article>)}</div><p className="form-note">{result.caution} AI 추천은 탐색을 돕는 참고 의견이며, 적성 검사나 진로의 정답은 아닙니다.</p></>}
 </div>;
}
