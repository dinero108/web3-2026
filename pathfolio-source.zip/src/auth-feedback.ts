export type AuthReturn = {kind:'none'|'error'|'signup'|'recovery'|'session'; message?:string};
export function readAuthReturn(hash:string,search:string):AuthReturn {
 const params=new URLSearchParams(search);new URLSearchParams(hash.replace(/^#/,'' )).forEach((v,k)=>params.set(k,v));
 if(params.has('error')||params.has('error_code'))return {kind:'error',message:params.get('error_code')==='otp_expired'?'인증 링크가 만료되었거나 이미 사용되었습니다. 이미 인증했다면 로그인해 주세요. 아직 인증하지 않았다면 새 메일을 받아 가장 최근 메일의 링크 또는 인증번호를 사용해 주세요.':'이메일 인증을 완료하지 못했어요. 다시 로그인하거나 새 인증 메일을 받아 주세요.'};
 if(params.get('type')==='recovery')return {kind:'recovery'};
 if(params.has('access_token')||params.has('code'))return {kind:params.get('type')==='signup'?'signup':'session'};
 return {kind:'none'};
}
export const PASSWORD_RULE='10자 이상, 영문 대문자·소문자·숫자·특수문자를 모두 포함해 주세요.';
export function validPassword(value:string){return value.length>=10&&value.length<=128&&/[A-Z]/.test(value)&&/[a-z]/.test(value)&&/[0-9]/.test(value)&&/[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(value);}
