export default function PortfolioLoadState({state,onRetry,onLogin}:{state:'loading'|'ready'|'error'|'auth';onRetry:()=>void;onLogin:()=>void}){
 const loading=state==='loading';
 return <section className="card empty" aria-live="polite"><h2>{loading?'저장된 기록을 확인하고 있어요':state==='auth'?'로그인 정보를 다시 확인해 주세요':'기록을 불러오지 못했어요'}</h2><p style={{fontSize:13,lineHeight:1.9,marginTop:16}}>{loading?'계정의 활동과 프로필을 불러오는 중입니다.': '조회가 완료되지 않아 활동 개수와 내용을 표시할 수 없습니다. 기록이 0개라는 의미는 아닙니다.'}</p>{!loading&&<div className="detail-actions"><button className="primary" onClick={onRetry}>다시 불러오기</button><button onClick={onLogin}>다시 로그인</button></div>}</section>;
}
