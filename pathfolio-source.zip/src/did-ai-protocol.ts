import {keccak256,toUtf8Bytes} from 'ethers';
export type AIRecord={id:string;title:string;type:string;date:string;note:string};
export type AIResult={summary:string;caution:string;recommendations:{title:string;reason:string;activityIds:string[];nextActivity:string;steps:string[];reflection:string}[]};
export type SavedAI={createdAt:string;records:AIRecord[];result:AIResult};
export const AI_ORIGIN='https://pathfolio.dinero.kr';
export const AI_ENDPOINT='https://uvzxyrbyszvmnlxchvoc.supabase.co/functions/v1/did-recommendations';
export function validateRecords(value:unknown):AIRecord[]{
 if(!Array.isArray(value)||value.length<1||value.length>10)throw Error('활동을 1~10개 선택해 주세요.');
 return value.map((r,i)=>{if(!r||r.id!==`r${i+1}`||r.date!==''||Object.keys(r).sort().join(',')!=='date,id,note,title,type'||typeof r.title!=='string'||!r.title.trim()||r.title.length>150||typeof r.type!=='string'||r.type.length>50||typeof r.note!=='string'||!r.note.trim()||r.note.length>1500)throw Error('전송할 활동 제목과 내용을 확인해 주세요.');return {id:r.id,title:r.title,type:r.type,date:'',note:r.note};});
}
export function aiMessage(address:string,issuedAt:string,records:AIRecord[]){return `Pathfolio AI recommendation v1\nOrigin: ${AI_ORIGIN}\nWallet: ${address.toLowerCase()}\nIssued At: ${issuedAt}\nContent hash: ${keccak256(toUtf8Bytes(JSON.stringify(records)))}\nI consent to send these reviewed activity texts via Supabase to Cloudflare Workers AI for recommendations. No transaction or gas fee.`;}
