import {useEffect,useState} from 'react';
import {authReturn,supabase} from './supabase';
export default function AuthResult({onLogin}:{onLogin:()=>void}){
 const [state,setState]=useState(authReturn.kind==='none'?'hidden':authReturn.kind==='error'?'error':'pending');
 useEffect(()=>{
  if(authReturn.kind==='none')return;
  if(authReturn.kind==='error'){history.replaceState(null,'',location.pathname);return;}
  let alive=true;
  const timeout=setTimeout(()=>{if(alive)setState('error');},15000);
  void supabase?.auth.getSession().then(({data,error})=>{
   if(!alive)return;clearTimeout(timeout);
   if(error||!data.session)setState('error');
   else setState(authReturn.kind==='recovery'?'hidden':'success');
  }).catch(()=>{if(alive){clearTimeout(timeout);setState('error');}});
  return()=>{alive=false;clearTimeout(timeout);};
 },[]);
 if(state==='hidden')return null;
 return <div className="overlay"><section className="modal auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-result-title"><h2 id="auth-result-title">{state==='pending'?'이메일 인증 확인 중…':state==='success'?'이메일 인증이 완료됐어요':'이메일 인증을 확인해 주세요'}</h2><p role="status">{state==='pending'?'잠시만 기다려 주세요. 계정을 연결하고 있습니다.':state==='success'?'로그인되었습니다. 이제 활동을 기록하고 나만의 포트폴리오를 만들 수 있어요.':authReturn.message||'인증을 완료하지 못했어요. 이미 인증했다면 로그인해 주세요. 아직 인증하지 않았다면 새 인증 메일을 받아 주세요.'}</p>{state!=='pending'&&<button className="primary wide" onClick={()=>{setState('hidden');if(state==='error')onLogin();}}>{state==='success'?'내 대시보드 시작하기':'로그인 · 인증 메일 다시 받기'}</button>}</section></div>;
}
