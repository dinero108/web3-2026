import {createClient} from '@supabase/supabase-js';
import {readAuthReturn} from './auth-feedback';
// Capture only return metadata before the SDK consumes URL credentials.
export const authReturn=readAuthReturn(location.hash,location.search);
export const url = (import.meta.env.VITE_SUPABASE_URL || 'https://uvzxyrbyszvmnlxchvoc.supabase.co') as string;
const key = (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_VdR88--LSogqzNg14NHSDA_WyaiUPBB') as string;
export const supabase = url && key ? createClient(url, key) : null;
export const redirectUrl = () => location.origin + location.pathname;
