import {useRef,useState} from 'react';
import {supabase} from './supabase';
export default function AccountDeletion({disabled,onBusy}:{disabled:boolean;onBusy:(busy:boolean)=>void}){
 const [open,setOpen]=useState(false),[password,setPassword]=useState(''),[confirmation,setConfirmation]=useState(''),[acknowledged,setAcknowledged]=useState(false),[busy,setBusy]=useState(false),[error,setError]=useState('');const lock=useRef(false);
 if(!open)return <div className="account-delete"><h3>회원탈퇴</h3><p className="form-note">계정과 계정에 저장된 활동·첨부파일을 삭제합니다.</p><button className="danger" disabled={disabled} onClick={()=>setOpen(true)}>회원탈퇴 안내 보기</button></div>;
 return <section className="account-delete" aria-label="회원탈퇴"><h3>계정을 영구 삭제할까요?</h3><ul><li>이메일 계정, 활동 기록, 프로필, 첨부파일과 저장된 AI 추천 결과가 삭제됩니다.</li><li>공유 링크는 더 이상 열리지 않으며, 삭제한 자료는 복구할 수 없습니다.</li><li>이미 다른 사람이 내려받은 자료와 블록체인에 발급한 SBT·거래 기록은 삭제되지 않습니다. 지갑 자체도 삭제되지 않습니다.</li></ul><p>필요한 기록은 위의 ‘기록 내려받기’로, 첨부파일은 각 활동에서 따로 보관해 주세요. 탈퇴를 시작한 뒤에는 취소할 수 없습니다.</p><form onSubmit={async e=>{
  e.preventDefault();if(lock.current||disabled||!supabase||!password||confirmation!=='탈퇴'||!acknowledged)return;
  lock.current=true;setBusy(true);onBusy(true);setError('');
  try{const {data,error:failure}=await supabase.functions.invoke('delete-account',{body:{password,confirmation,acknowledged}});
   if(failure){let message='탈퇴 완료 여부를 확인하지 못했어요. 계정이 유지되어 있다면 다시 요청해 주세요.';try{const body=await failure.context?.json();if(body?.error)message=body.error;}catch{}throw Error(message);}
   if(data?.deleted!==true)throw Error('탈퇴 완료 여부를 확인하지 못했어요. 다시 시도해 주세요.');
   await supabase.auth.signOut({scope:'local'});location.replace('./?account=deleted');
  }catch(e){setError(e instanceof Error?e.message:'탈퇴를 완료하지 못했어요.');}
  finally{setPassword('');lock.current=false;setBusy(false);onBusy(false);}
 }}><fieldset disabled={busy||disabled}><label>현재 비밀번호<input type="password" autoComplete="current-password" required maxLength={128} value={password} onChange={e=>setPassword(e.target.value)}/></label><label>확인을 위해 ‘탈퇴’를 입력해 주세요<input autoComplete="off" required value={confirmation} onChange={e=>setConfirmation(e.target.value)}/></label><label className="analysis-consent"><input type="checkbox" checked={acknowledged} onChange={e=>setAcknowledged(e.target.checked)}/><span>삭제 범위와 복구할 수 없다는 점을 확인했습니다.</span></label><div className="detail-actions"><button className="danger" type="submit" disabled={!password||confirmation!=='탈퇴'||!acknowledged}>{busy?'계정과 파일 정리 중…':'계정 영구 삭제'}</button><button type="button" onClick={()=>{setOpen(false);setPassword('');setConfirmation('');setAcknowledged(false);setError('');}}>취소</button></div></fieldset></form>{busy&&<p role="status">첨부파일을 정리하고 있어요. 화면을 닫지 말고 기다려 주세요.</p>}{error&&<p role="alert">{error}</p>}</section>;
}
