import {useEffect, useRef, useState} from 'react';
import type {User} from '@supabase/supabase-js';
import {supabase} from './supabase';
import {removeFiles} from './attachments';
import type {Data} from './portfolio-types';
import {isPortfolio} from './portfolio-storage';
const blank = (): Data => ({name:'', interests:[], activities:[], done:[]});
export function usePortfolio() {
  const [data,setData]=useState<Data>(blank);
  const [user,setUser]=useState<User|null>(null);
  const [ready,setReady]=useState(false);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState('');
  const [recovery,setRecovery]=useState(false);
  const [loadState,setLoadState]=useState<'loading'|'ready'|'error'|'auth'>('loading');
  const reload=useRef<()=>void>(()=>{});
  const owner=useRef<string|null>(null);
  const userRef=useRef<User|null>(null);
  const generation=useRef(0);
  const saving=useRef(false);
  useEffect(()=>{
    let alive=true;
    async function load(next:User|null) {
      const version=++generation.current;
      owner.current=next?.id??null;
      setUser(next);setData(blank());setReady(false);setLoadState('loading');setBusy(false);saving.current=false;
      try {
        if(next && supabase) {
          let response=await supabase.from('portfolios').select('data').eq('user_id',next.id).maybeSingle();
          if(!alive||version!==generation.current)return;
          if(response.status===401||['PGRST301','PGRST303'].includes(response.error?.code||'')){
            // Refresh once when the server rejects a token, even if the device clock says it is valid.
            const refreshed=await supabase.auth.refreshSession();
            if(!alive||version!==generation.current)return;
            if(refreshed.error||refreshed.data.session?.user.id!==next.id){
              setLoadState('auth');setNotice('로그인 정보를 확인하지 못했어요. 기록이 삭제된 것은 아닙니다. 다시 로그인해 주세요.');return;
            }
            response=await supabase.from('portfolios').select('data').eq('user_id',next.id).maybeSingle();
            if(!alive||version!==generation.current)return;
            if(response.status===401||['PGRST301','PGRST303'].includes(response.error?.code||'')){
              setLoadState('auth');setNotice('로그인 유효기간이 지났어요. 다시 로그인하면 저장된 기록을 불러옵니다.');return;
            }
          }
          const {data:row,error}=response;
          if(error)throw error;
          if(!alive||version!==generation.current)return;
          if(row){if(!isPortfolio(row.data))throw Error('저장된 기록의 형식을 확인해 주세요.');setData(row.data);}
          setNotice('내 계정의 기록을 불러왔어요.');
        } else {
          setData(blank());setNotice('로그인 후 이용해 주세요.');
        }
        if(alive&&version===generation.current){setReady(true);setLoadState('ready');}
      }catch{if(alive&&version===generation.current){setLoadState('error');setNotice('기록을 불러오지 못했어요. 기록이 없는 상태가 아닙니다. 다시 불러오기를 눌러 주세요.');}}
    }
    reload.current=()=>{if(alive&&!saving.current)void load(owner.current===userRef.current?.id?userRef.current:null);};
    if(!supabase){void load(null);return()=>{alive=false;generation.current++;};}
    const {data:{subscription}}=supabase.auth.onAuthStateChange((event,session)=>{
      if(event==='PASSWORD_RECOVERY')setRecovery(true);
      if(event==='SIGNED_OUT')setRecovery(false);
      if(event==='INITIAL_SESSION'||owner.current!==(session?.user.id??null)) {
        // Leave the auth callback before querying the database (auth holds a lock).
        owner.current=session?.user.id??null;
        const ticket=++generation.current;setData(blank());setReady(false);setLoadState('loading');setUser(session?.user??null);userRef.current=session?.user??null;
        setTimeout(()=>{if(alive&&ticket===generation.current)void load(session?.user??null);},0);
      }
    });
    return()=>{alive=false;generation.current++;subscription.unsubscribe();};
  },[]);
  const renderedGeneration=generation.current;
  async function save(next:Data) {
    if(!user||!supabase||!ready||saving.current||renderedGeneration!==generation.current||(user?.id??null)!==owner.current)return false;
    if(!isPortfolio(next)||JSON.stringify(next).length>100000){setNotice('기록 형식 또는 저장 용량을 확인해 주세요.');return false;}
    const version=generation.current, uid=owner.current;
    saving.current=true;setBusy(true);
    try {
      if(uid&&supabase){const {error}=await supabase.from('portfolios').upsert({user_id:uid,data:next},{onConflict:'user_id'});if(error)throw error;}
      else return false;
      if(version!==generation.current)return false;
      setData(next);setNotice(uid?'내 계정에 저장했어요.':'이 브라우저에 저장했어요.');
      if(uid){const kept=new Set(next.activities.flatMap(a=>(a.attachments||[]).map(f=>f.path)));const removed=data.activities.flatMap(a=>a.attachments||[]).filter(f=>f.path.startsWith(uid+'/')&&!kept.has(f.path));try{for(let i=0;i<removed.length;i+=5)await removeFiles(removed.slice(i,i+5),uid);}catch{if(version===generation.current)setNotice('기록은 저장했지만 이전 첨부파일 정리를 완료하지 못했어요. 운영자에게 문의해 주세요.');}}return true;
    }catch{if(version===generation.current)setNotice('저장하지 못했어요. 연결 상태를 확인하고 다시 시도해 주세요.');return false;}
    finally{if(version===generation.current){saving.current=false;setBusy(false);}}
  }
  async function logout(){
    if(!supabase||saving.current)return;
    setBusy(true);
    const {error}=await supabase.auth.signOut({scope:'local'});
    if(error){setNotice('로그아웃하지 못했어요. 다시 시도해 주세요.');setBusy(false);}
  }
  return {data,user,ready,busy,notice,setNotice,save,logout,recovery,setRecovery,loadState,retryLoad:()=>reload.current()};
}
