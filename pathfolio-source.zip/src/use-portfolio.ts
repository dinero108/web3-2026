import {useEffect, useRef, useState} from 'react';
import type {User} from '@supabase/supabase-js';
import {supabase} from './supabase';
import type {Data} from './portfolio-types';
import {loadBrowserPortfolio, saveBrowserPortfolio, isPortfolio} from './portfolio-storage';
const blank = (): Data => ({name:'', interests:[], activities:[], done:[]});
export function usePortfolio() {
  const [data,setData]=useState<Data>(blank);
  const [user,setUser]=useState<User|null>(null);
  const [ready,setReady]=useState(false);
  const [busy,setBusy]=useState(false);
  const [notice,setNotice]=useState('');
  const [recovery,setRecovery]=useState(false);
  const owner=useRef<string|null>(null);
  const generation=useRef(0);
  const saving=useRef(false);
  useEffect(()=>{
    let alive=true;
    async function load(next:User|null) {
      const version=++generation.current;
      owner.current=next?.id??null;
      setUser(next);setData(blank());setReady(false);setBusy(false);saving.current=false;
      try {
        if(next && supabase) {
          const {data:row,error}=await supabase.from('portfolios').select('data').eq('user_id',next.id).maybeSingle();
          if(error)throw error;
          if(!alive||version!==generation.current)return;
          if(row){if(!isPortfolio(row.data))throw Error('저장된 기록의 형식을 확인해 주세요.');setData(row.data);}
          setNotice('내 계정의 기록을 불러왔어요.');
        } else {
          setData(loadBrowserPortfolio()??blank());
          setNotice('게스트 기록은 이 브라우저에만 저장됩니다.');
        }
        if(alive&&version===generation.current)setReady(true);
      }catch{if(alive&&version===generation.current)setNotice('기록을 불러오지 못했어요. 새로고침 후 다시 시도해 주세요.');}
    }
    if(!supabase){void load(null);return()=>{alive=false;generation.current++;};}
    const {data:{subscription}}=supabase.auth.onAuthStateChange((event,session)=>{
      if(event==='PASSWORD_RECOVERY')setRecovery(true);
      if(event==='SIGNED_OUT')setRecovery(false);
      if(event==='INITIAL_SESSION'||owner.current!==(session?.user.id??null)) {
        // Leave the auth callback before querying the database (auth holds a lock).
        owner.current=session?.user.id??null;
        const ticket=++generation.current;setData(blank());setReady(false);setUser(session?.user??null);
        setTimeout(()=>{if(alive&&ticket===generation.current)void load(session?.user??null);},0);
      }
    });
    return()=>{alive=false;generation.current++;subscription.unsubscribe();};
  },[]);
  const renderedGeneration=generation.current;
  async function save(next:Data) {
    if(!ready||saving.current||renderedGeneration!==generation.current||(user?.id??null)!==owner.current)return false;
    if(!isPortfolio(next)||JSON.stringify(next).length>100000){setNotice('기록 형식 또는 저장 용량을 확인해 주세요.');return false;}
    const version=generation.current, uid=owner.current;
    saving.current=true;setBusy(true);
    try {
      if(uid&&supabase){const {error}=await supabase.from('portfolios').upsert({user_id:uid,data:next},{onConflict:'user_id'});if(error)throw error;}
      else saveBrowserPortfolio(next);
      if(version!==generation.current)return false;
      setData(next);setNotice(uid?'내 계정에 저장했어요.':'이 브라우저에 저장했어요.');return true;
    }catch{if(version===generation.current)setNotice('저장하지 못했어요. 연결 상태를 확인하고 다시 시도해 주세요.');return false;}
    finally{if(version===generation.current){saving.current=false;setBusy(false);}}
  }
  async function logout(){
    if(!supabase||saving.current)return;
    setBusy(true);
    const {error}=await supabase.auth.signOut({scope:'local'});
    if(error){setNotice('로그아웃하지 못했어요. 다시 시도해 주세요.');setBusy(false);}
  }
  return {data,user,ready,busy,notice,setNotice,save,logout,recovery,setRecovery};
}
