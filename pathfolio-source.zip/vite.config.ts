import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  base: './',
  plugins: [react()],
  define: { 'process.env.NEXT_PUBLIC_PORTFOLIO_MODE': JSON.stringify('browser') },
  build: { outDir: 'dist', emptyOutDir: true },
});
