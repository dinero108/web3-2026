import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  base: './',
  plugins: [react(), {name:'local-vault-policy',apply:'build',transformIndexHtml(html:string){return html.replace('<head>',`<head><meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self' https://uvzxyrbyszvmnlxchvoc.supabase.co/functions/v1/did-recommendations; object-src 'none'; base-uri 'self'; form-action 'none'"><meta name="referrer" content="no-referrer">`);}}],
  define: { 'process.env.NEXT_PUBLIC_PORTFOLIO_MODE': JSON.stringify('browser') },
  build: { outDir: 'dist', assetsDir:'', emptyOutDir: true },
});
