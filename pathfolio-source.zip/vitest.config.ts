import {defineConfig} from 'vitest/config';
export default defineConfig({test:{include:['tests/**/*.test.{ts,tsx}']},define:{'process.env.NEXT_PUBLIC_PORTFOLIO_MODE':JSON.stringify('browser')}});
