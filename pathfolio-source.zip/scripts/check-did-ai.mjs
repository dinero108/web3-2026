import {Wallet} from 'ethers';
import {aiMessage,AI_ENDPOINT} from '../src/did-ai-protocol.ts';
const wallet=Wallet.createRandom();
const records=[{id:'r1',title:'환경 지도 만들기',type:'프로젝트',date:'',note:'친구들과 학교 주변 쓰레기 배출 현황을 조사해 지도로 정리했습니다. 역할을 나누고 결과를 비교하는 방법을 배웠습니다. 다음에는 자료를 더 체계적으로 분석해 보고 싶습니다.'}];
const issuedAt=new Date().toISOString();const signature=await wallet.signMessage(aiMessage(wallet.address,issuedAt,records));
const body=JSON.stringify({consent:true,address:wallet.address,issuedAt,signature,records});
const response=await fetch(AI_ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json'},body,signal:AbortSignal.timeout(60000)});
console.log('STATUS',response.status);console.log(await response.text());
if(!response.ok)process.exitCode=1;
