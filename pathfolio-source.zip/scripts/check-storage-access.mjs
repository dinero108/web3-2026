import {createClient} from '@supabase/supabase-js';
const c=createClient('https://uvzxyrbyszvmnlxchvoc.supabase.co','sb_publishable_VdR88--LSogqzNg14NHSDA_WyaiUPBB',{auth:{persistSession:false}});
const {error}=await c.storage.from('activity-files').upload('11111111-1111-4111-8111-111111111111/anonymous-probe.txt',new Blob(['non-sensitive access test'],{type:'text/plain'}));
if(!error)throw Error('Anonymous upload unexpectedly allowed');
console.log(JSON.stringify({anonymousUploadBlocked:true,status:error.statusCode,message:error.message}));
