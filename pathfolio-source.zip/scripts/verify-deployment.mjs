import {JsonRpcProvider,keccak256} from 'ethers';
import fs from 'node:fs';
const artifact=JSON.parse(fs.readFileSync(new URL('../src/generated/pathfolio-sbt.json',import.meta.url)));
const address='0x86E9162216353DC5aAa464F902BD2825CfBF6181';
const hash='0x49dd3cb387bbb6a35534e1e96c68ff25db08761bbf136e872d43810a8f4ffa5f';
const rpc=new JsonRpcProvider('https://ethereum-sepolia-rpc.publicnode.com');
try {
 const [network,code,receipt]=await Promise.all([rpc.getNetwork(),rpc.getCode(address),rpc.getTransactionReceipt(hash)]);
 if(network.chainId!==11155111n||!receipt||receipt.status!==1||receipt.contractAddress?.toLowerCase()!==address.toLowerCase()||keccak256(code)!==keccak256('0x'+artifact.evm.deployedBytecode.object))throw Error('Deployment verification failed');
 console.log(JSON.stringify({chainId:Number(network.chainId),address,transaction:hash,block:receipt.blockNumber,status:receipt.status,runtimeMatches:true}));
} finally {rpc.destroy();}
