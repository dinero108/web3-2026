// @vitest-environment jsdom
import {act, cleanup, renderHook, waitFor} from '@testing-library/react';
import {afterEach, beforeEach, expect, test, vi} from 'vitest';
const mock=vi.hoisted(()=>({listener:null as any, select:vi.fn(), upsert:vi.fn(), signOut:vi.fn()}));
vi.mock('../src/supabase',()=>({supabase:{
 auth:{onAuthStateChange:(callback:any)=>{mock.listener=callback;return {data:{subscription:{unsubscribe:vi.fn()}}};}, signOut:mock.signOut},
 from:()=>({select:()=>({eq:()=>({maybeSingle:mock.select})}),upsert:mock.upsert})
}}));
import {usePortfolio} from '../src/use-portfolio';
const empty={name:'',interests:[],activities:[],done:[]};
const row=(name:string)=>({data:{data:{...empty,name}},error:null});
const emit=(event:string,id:string|null)=>act(()=>mock.listener(event,id?{user:{id,email:`${id}@example.invalid`}}:null));
beforeEach(()=>{vi.clearAllMocks();localStorage.clear();mock.select.mockResolvedValue(row('Alice'));mock.upsert.mockResolvedValue({error:null});});
afterEach(cleanup);
test('guest records are preserved but never silently copied into an account',async()=>{
 localStorage.setItem('pathfolio.portfolio.v1',JSON.stringify({...empty,name:'Guest'}));
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION',null);
 await waitFor(()=>expect(result.current.data.name).toBe('Guest'));
 emit('SIGNED_IN','alice');expect(result.current.data.name).toBe('');
 await waitFor(()=>expect(result.current.data.name).toBe('Alice'));
 expect(mock.upsert).not.toHaveBeenCalled();
 emit('SIGNED_OUT',null);expect(result.current.data.name).toBe('');
 await waitFor(()=>expect(result.current.data.name).toBe('Guest'));
});
test('late cloud response from a previous account cannot replace the next account',async()=>{
 let resolve:any;mock.select.mockImplementationOnce(()=>new Promise(r=>{resolve=r;})).mockResolvedValueOnce(row('Bob'));
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(mock.select).toHaveBeenCalledTimes(1));emit('SIGNED_IN','bob');
 await waitFor(()=>expect(result.current.data.name).toBe('Bob'));
 await act(async()=>resolve(row('Alice')));expect(result.current.data.name).toBe('Bob');
});
test('failed cloud loading prevents blank records from overwriting existing data',async()=>{
 mock.select.mockResolvedValue({data:null,error:Error('offline')});
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.notice).toContain('불러오지 못'));
 expect(result.current.ready).toBe(false);await act(async()=>{expect(await result.current.save(empty)).toBe(false);});
 expect(mock.upsert).not.toHaveBeenCalled();
});
test('a save completing after logout cannot restore private records',async()=>{
 let resolve:any;mock.upsert.mockImplementation(()=>new Promise(r=>{resolve=r;}));
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.ready).toBe(true));
 let pending:Promise<boolean>;act(()=>{pending=result.current.save({...empty,name:'private'});});
 emit('SIGNED_OUT',null);await waitFor(()=>expect(result.current.user).toBe(null));
 await act(async()=>{resolve({error:null});expect(await pending).toBe(false);});
 expect(result.current.data.name).not.toBe('private');
});
test('queued sign-in is discarded if sign-out occurs before it loads',async()=>{
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');emit('SIGNED_OUT',null);
 await waitFor(()=>expect(result.current.ready).toBe(true));
 expect(result.current.user).toBe(null);expect(mock.select).not.toHaveBeenCalled();
});
test('an old form/import callback cannot save to the next signed-in account',async()=>{
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.ready).toBe(true));const staleSave=result.current.save;
 mock.select.mockResolvedValue(row('Bob'));emit('SIGNED_IN','bob');
 await waitFor(()=>expect(result.current.data.name).toBe('Bob'));
 await act(async()=>{expect(await staleSave({...empty,name:'Alice private import'})).toBe(false);});
 expect(mock.upsert).not.toHaveBeenCalled();expect(result.current.data.name).toBe('Bob');
});
