// @vitest-environment jsdom
import {act, cleanup, renderHook, waitFor} from '@testing-library/react';
import {afterEach, beforeEach, expect, test, vi} from 'vitest';
const mock=vi.hoisted(()=>({listener:null as any, select:vi.fn(), upsert:vi.fn(), signOut:vi.fn(), refreshSession:vi.fn()}));
vi.mock('../src/supabase',()=>({supabase:{
 auth:{onAuthStateChange:(callback:any)=>{mock.listener=callback;return {data:{subscription:{unsubscribe:vi.fn()}}};}, signOut:mock.signOut,refreshSession:mock.refreshSession},
 from:()=>({select:()=>({eq:()=>({maybeSingle:mock.select})}),upsert:mock.upsert})
}}));
import {usePortfolio} from '../src/use-portfolio';
const empty={name:'',interests:[],activities:[],done:[]};
const row=(name:string)=>({data:{data:{...empty,name}},error:null});
const emit=(event:string,id:string|null)=>act(()=>mock.listener(event,id?{user:{id,email:`${id}@example.invalid`}}:null));
beforeEach(()=>{vi.clearAllMocks();localStorage.clear();mock.select.mockResolvedValue(row('Alice'));mock.upsert.mockResolvedValue({error:null});});
afterEach(cleanup);
test('guest data stays hidden and cannot be saved without login',async()=>{
 localStorage.setItem('pathfolio.portfolio.v1',JSON.stringify({...empty,name:'Guest'}));
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION',null);
 await waitFor(()=>expect(result.current.ready).toBe(true));expect(result.current.data.name).toBe('');
 expect(await result.current.save({...empty,name:'Blocked'})).toBe(false);expect(JSON.parse(localStorage.getItem('pathfolio.portfolio.v1')!).name).toBe('Guest');
 emit('SIGNED_IN','alice');expect(result.current.data.name).toBe('');
 await waitFor(()=>expect(result.current.data.name).toBe('Alice'));
 expect(mock.upsert).not.toHaveBeenCalled();
 emit('SIGNED_OUT',null);expect(result.current.data.name).toBe('');
 await waitFor(()=>expect(result.current.ready).toBe(true));expect(result.current.data.name).toBe('');
 expect(await result.current.save({...empty,name:'Blocked'})).toBe(false);expect(JSON.parse(localStorage.getItem('pathfolio.portfolio.v1')!).name).toBe('Guest');
});
test('late cloud response from a previous account cannot replace the next account',async()=>{
 let resolve:any;mock.select.mockImplementationOnce(()=>new Promise(r=>{resolve=r;})).mockResolvedValueOnce(row('Bob'));
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(mock.select).toHaveBeenCalledTimes(1));emit('SIGNED_IN','bob');
 await waitFor(()=>expect(result.current.data.name).toBe('Bob'));
 await act(async()=>resolve(row('Alice')));expect(result.current.data.name).toBe('Bob');
});
test('failed cloud loading prevents blank records from overwriting existing data',async()=>{
 mock.select.mockResolvedValue({data:null,error:Error('offline')});
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.notice).toContain('불러오지 못'));
 expect(result.current.ready).toBe(false);await act(async()=>{expect(await result.current.save(empty)).toBe(false);});
 expect(mock.upsert).not.toHaveBeenCalled();
});
test('a save completing after logout cannot restore private records',async()=>{
 let resolve:any;mock.upsert.mockImplementation(()=>new Promise(r=>{resolve=r;}));
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.ready).toBe(true));
 let pending:Promise<boolean>;act(()=>{pending=result.current.save({...empty,name:'private'});});
 emit('SIGNED_OUT',null);await waitFor(()=>expect(result.current.user).toBe(null));
 await act(async()=>{resolve({error:null});expect(await pending).toBe(false);});
 expect(result.current.data.name).not.toBe('private');
});
test('queued sign-in is discarded if sign-out occurs before it loads',async()=>{
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');emit('SIGNED_OUT',null);
 await waitFor(()=>expect(result.current.ready).toBe(true));
 expect(result.current.user).toBe(null);expect(mock.select).not.toHaveBeenCalled();
});
test('an old form/import callback cannot save to the next signed-in account',async()=>{
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.ready).toBe(true));const staleSave=result.current.save;
 mock.select.mockResolvedValue(row('Bob'));emit('SIGNED_IN','bob');
 await waitFor(()=>expect(result.current.data.name).toBe('Bob'));
 await act(async()=>{expect(await staleSave({...empty,name:'Alice private import'})).toBe(false);});
 expect(mock.upsert).not.toHaveBeenCalled();expect(result.current.data.name).toBe('Bob');
});
test('server-expired token is refreshed once and existing records become visible',async()=>{
 mock.select.mockResolvedValueOnce({data:null,error:{code:'PGRST303'},status:401}).mockResolvedValue(row('Existing records'));
 mock.refreshSession.mockResolvedValue({data:{session:{user:{id:'alice'}}},error:null});
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.ready).toBe(true));
 expect(mock.refreshSession).toHaveBeenCalledTimes(1);expect(mock.select).toHaveBeenCalledTimes(2);
 expect(result.current.data.name).toBe('Existing records');expect(mock.upsert).not.toHaveBeenCalled();
});
test('failed token refresh exposes re-login state without writing blank records',async()=>{
 mock.select.mockResolvedValue({data:null,error:{code:'PGRST303'},status:401});
 mock.refreshSession.mockResolvedValue({data:{session:null},error:Error('expired')});
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.loadState).toBe('auth'));
 expect(result.current.ready).toBe(false);expect(await result.current.save(empty)).toBe(false);expect(mock.upsert).not.toHaveBeenCalled();
});
test('failed loading can retry without reloading the browser',async()=>{
 mock.select.mockResolvedValueOnce({data:null,error:Error('offline')}).mockResolvedValue(row('Restored view'));
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(result.current.loadState).toBe('error'));act(()=>result.current.retryLoad());
 await waitFor(()=>expect(result.current.data.name).toBe('Restored view'));expect(mock.upsert).not.toHaveBeenCalled();
});
test('refresh response from a previous account cannot reload its records after account switch',async()=>{
 let resolve:any;mock.select.mockResolvedValueOnce({data:null,error:{code:'PGRST303'},status:401}).mockResolvedValue(row('Bob'));
 mock.refreshSession.mockImplementationOnce(()=>new Promise(r=>{resolve=r}));
 const {result}=renderHook(usePortfolio);emit('INITIAL_SESSION','alice');
 await waitFor(()=>expect(mock.refreshSession).toHaveBeenCalledTimes(1));emit('SIGNED_IN','bob');
 await waitFor(()=>expect(result.current.data.name).toBe('Bob'));
 await act(async()=>resolve({data:{session:{user:{id:'alice'}}},error:null}));
 expect(result.current.data.name).toBe('Bob');expect(mock.select).toHaveBeenCalledTimes(2);
});
