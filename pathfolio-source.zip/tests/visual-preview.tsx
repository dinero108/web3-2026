import AIRecommendations from '../src/did-ai';
// Development-only visual fixture. This entry is not included in the production build.
import {createRoot} from 'react-dom/client';
import {useState} from 'react';
import {Leaf,Download,LockKeyhole} from 'lucide-react';
import {Overview,WorkspaceNav,sections} from '../src/did-overview';
import {ActivityList,ActivityView} from '../src/did-workspace';
import '../src/globals.css';
import '../src/did.css';
import '../src/did-redesign.css';
import type {LocalActivity} from '../src/did-vault';
if(!import.meta.env.DEV)throw Error('Visual fixtures are development-only.');
const activities:LocalActivity[]=[{id:'sample-1',title:'함께 만드는 우리 동네 환경 지도',type:'프로젝트',date:'2026-11-10',org:'교내 환경 동아리',note:'동아리 친구들과 학교 주변의 쓰레기 배출 현황을 조사하고, 더 깨끗한 동네를 위한 지도를 만들었습니다. 역할을 나누고 조사 결과를 정리하면서 협업의 중요성을 배웠습니다.',files:[]},{id:'sample-2',title:'읽고 나누는 기술과 사회 이야기',type:'독서',date:'2026-11-08',org:'독서 모임',note:'기술이 사람들의 일상을 어떻게 바꾸는지 읽고, 생각을 나눴습니다.',files:[]},{id:'sample-3',title:'첫 웹사이트, 나의 포트폴리오 만들기',type:'프로젝트',date:'2026-11-05',org:'나의 프로젝트',note:'처음으로 직접 웹사이트를 만들며 아이디어를 구현하는 경험을 했습니다.',files:[]}];
function Preview(){const [tab,setTab]=useState('overview'),[id,setId]=useState('');const data={name:'샘플 사용자',activities};const did='did:pkh:eip155:1:0x1234567890123456789012345678901234567890';const go=(t:string)=>{setTab(t==='new'?'activities':t);setId('');};return <div className="dv-app dv-authenticated"><header className="dv-header"><span className="dv-brand"><Leaf/>패스폴리오 <small>DID</small></span><span className="pf-fixture-notice">디자인 확인용 샘플 · 실제 계정 자료가 아닙니다</span><div className="dv-header-actions"><button onClick={()=>go('profile')}>내 프로필</button><button><LockKeyhole size={15}/> 잠그기</button></div></header><WorkspaceNav active={tab} go={go} busy={false}/><main className="dv-main"><div className="dv-workspace-title"><div><span className="pf-kicker">MY PRIVATE PORTFOLIO</span><h1>{tab==='overview'?'샘플 사용자의 보관함':sections.find(s=>s.id===tab)?.title}</h1><p>나의 경험을 모으고, 다음 가능성을 발견하세요.</p></div><button className="dv-outline"><Download size={17}/>암호화 백업</button></div>{tab==='overview'?<Overview data={data} did={did} go={go} open={id=>{setTab('activities');setId(id);}} backup={()=>{}}/>:tab==='ai'?<AIRecommendations activities={activities} did={did} save={async()=>false}/>:id?<ActivityView activity={activities.find(a=>a.id===id)!} did={did} busy={false} run={async()=>{}} save={async()=>false} remove={async()=>{}} back={()=>setId('')} notify={()=>{}}/>:<ActivityList activities={activities} busy={false} run={async()=>{}} save={async()=>false} open={setId}/>}</main></div>;}
const root=import.meta.hot?.data.root||createRoot(document.getElementById('root')!);if(import.meta.hot)import.meta.hot.data.root=root;root.render(<Preview/>);
