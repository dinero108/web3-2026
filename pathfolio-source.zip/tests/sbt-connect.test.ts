// @vitest-environment jsdom
import {createElement} from 'react';
import {render,screen,fireEvent,waitFor,cleanup} from '@testing-library/react';
import {afterEach,expect,test,vi} from 'vitest';
const state=vi.hoisted(()=>({events:new Map<string,()=>void>()}));
vi.mock('../src/sbt-client',async importOriginal=>({
 ...await importOriginal<typeof import('../src/sbt-client')>(),
 wallet:()=>({on:(name:string,fn:()=>void)=>state.events.set(name,fn),removeListener:(name:string)=>state.events.delete(name)}),
 connectWallet:async()=>{state.events.get('accountsChanged')?.();return {address:'0x1111111111111111111111111111111111111111'};},
 switchNetwork:async()=>{state.events.get('chainChanged')?.();}
}));
import SBTPanel from '../src/sbt-panel';
afterEach(()=>{cleanup();state.events.clear();});
test('first authorization account event does not discard a successful wallet connection',async()=>{
 render(createElement(SBTPanel,{activities:[],deployOnly:true}));
 fireEvent.click(screen.getByRole('button',{name:'MetaMask 연결'}));
 await waitFor(()=>expect(screen.getByRole('status').textContent).toContain('연결 완료'));
 expect((screen.getByRole('button',{name:'Sepolia에 컨트랙트 배포'}) as HTMLButtonElement).disabled).toBe(false);
});
test('switching network reconnects automatically after the wallet emits its change event',async()=>{
 render(createElement(SBTPanel,{activities:[],deployOnly:true}));
 fireEvent.click(screen.getByRole('button',{name:'Sepolia로 전환'}));
 await waitFor(()=>expect(screen.getByRole('status').textContent).toContain('연결 완료'));
 expect(screen.getByText('0x1111111111111111111111111111111111111111')).toBeTruthy();
});
