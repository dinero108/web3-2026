// @vitest-environment jsdom
import {beforeEach,afterEach,describe,it,expect,vi} from 'vitest';
import {render,screen,fireEvent,waitFor,cleanup} from '@testing-library/react';
import Recommendations from '../src/recommendations';
import {prepareRecords,validateResult} from '../supabase/functions/activity-recommendations/policy';
import {readRoute} from '../src/activity-route';
const {invoke}=vi.hoisted(()=>({invoke:vi.fn()}));
vi.mock('../src/supabase',()=>({supabase:{functions:{invoke}}}));
const a={id:'one',title:'환경 지도',type:'프로젝트',date:'2026-11-01',note:'학교 주변 분리배출 지도를 만들었다.',org:'학교',attachments:[{path:'private/file.pdf',name:'private.pdf',size:1,type:'application/pdf'}]};
const output={summary:'환경 지도를 만드는 경험을 기록했어요.',caution:'아직 기록이 적어요.',recommendations:[{title:'환경 정보 디자인 탐색',reason:'지도를 만든 경험에서 출발해요.',activityIds:['one'],nextActivity:'표지판 시안 만들기',steps:['지도에서 개선할 점 찾기'],reflection:'어떤 표현이 잘 전달되었나요?'}],createdAt:'2026-11-02T00:00:00Z',count:1};
beforeEach(()=>{invoke.mockReset();});afterEach(()=>{cleanup();});
describe('activity-based recommendations',()=>{
 it('does not send attachments, organization or extra private fields',()=>{expect(prepareRecords([a])).toEqual([{id:a.id,title:a.title,type:a.type,date:a.date,note:a.note}]);});
 it('bounds input and selects latest records',()=>{const data=prepareRecords(Array.from({length:40},(_,i)=>({...a,id:String(i),date:i===39?'2026-12-01':'2026-01-01',note:'a'.repeat(3000)})));expect(data).toHaveLength(30);expect(data[0].id).toBe('39');expect(data[0].note).toHaveLength(1500);});
 it('rejects invented evidence and malformed results',()=>{expect(()=>validateResult({...output,recommendations:[{...output.recommendations[0],activityIds:['invented']}]},[a])).toThrow();expect(()=>validateResult({recommendations:[]},[a])).toThrow();expect(validateResult(output,[a]).summary).toBe(output.summary);});
 it('redirects legacy roadmap links to recommendations',()=>{expect(readRoute('?tab=roadmap').tab).toBe('recommendations');});
 it('shows first-record invitation without analyzing an empty account',()=>{render(<Recommendations activities={[]} onRecord={()=>{}} onOpen={()=>{}}/>);expect(screen.getByText('추천의 시작은 나의 첫 기록이에요')).toBeTruthy();expect(invoke).not.toHaveBeenCalled();});
 it('requires consent and opens real evidence records',async()=>{invoke.mockResolvedValue({data:output});const open=vi.fn();render(<Recommendations activities={[a]} onRecord={()=>{}} onOpen={open}/>);const button=screen.getByRole('button',{name:'내 기록으로 AI 추천 받기'});expect((button as HTMLButtonElement).disabled).toBe(true);fireEvent.click(screen.getByRole('checkbox'));fireEvent.click(button);await screen.findByText(output.summary);expect(invoke).toHaveBeenCalledWith('activity-recommendations',{body:{consent:true}});fireEvent.click(screen.getByRole('button',{name:'환경 지도 ↗'}));expect(open).toHaveBeenCalledWith('one');});
 it('shows setup failure honestly instead of fake recommendations',async()=>{invoke.mockResolvedValue({error:{context:{json:async()=>({error:'AI 연결 준비 중'})}}});render(<Recommendations activities={[a]} onRecord={()=>{}} onOpen={()=>{}}/>);fireEvent.click(screen.getByRole('checkbox'));fireEvent.click(screen.getByRole('button',{name:'내 기록으로 AI 추천 받기'}));expect(await screen.findByRole('alert')).toHaveProperty('textContent','AI 연결 준비 중');expect(screen.queryByText('기록에서 발견한 흐름')).toBeNull();});
 it('ignores a response from before activity edits',async()=>{let resolve:any;invoke.mockImplementation(()=>new Promise(r=>{resolve=r}));const view=render(<Recommendations activities={[a]} onRecord={()=>{}} onOpen={()=>{}}/>);fireEvent.click(screen.getByRole('checkbox'));fireEvent.click(screen.getByRole('button',{name:'내 기록으로 AI 추천 받기'}));view.rerender(<Recommendations activities={[{...a,note:'수정된 기록'}]} onRecord={()=>{}} onOpen={()=>{}}/>);resolve({data:output});await waitFor(()=>expect((screen.getByRole('button',{name:'내 기록으로 AI 추천 받기'}) as HTMLButtonElement).disabled).toBe(false));expect(screen.queryByText(output.summary)).toBeNull();});
});
