// @vitest-environment jsdom
import {expect,test,vi,beforeEach} from 'vitest';
import {validateFiles,validAttachments,ownedPaths,MAX_FILE_SIZE} from '../src/attachment-rules';
const mock=vi.hoisted(()=>({getUser:vi.fn(),upload:vi.fn(),remove:vi.fn(),download:vi.fn()}));
vi.mock('../src/supabase',()=>({supabase:{auth:{getUser:mock.getUser},storage:{from:()=>mock}}}));
import {uploadFiles,downloadFile} from '../src/attachments';
import {createProof} from '../src/sbt-client';
const uid='11111111-1111-4111-8111-111111111111';
beforeEach(()=>{vi.clearAllMocks();mock.getUser.mockResolvedValue({data:{user:{id:uid}}});mock.upload.mockResolvedValue({error:null});mock.remove.mockResolvedValue({error:null});});
test('reject oversized, empty, executable and too many attachments',()=>{
 for(const f of [new File([],'empty.txt'),new File(['x'],'run.exe')])expect(()=>validateFiles([f])).toThrow();
 const large=new File(['x'],'large.pdf');Object.defineProperty(large,'size',{value:MAX_FILE_SIZE+1});expect(()=>validateFiles([large])).toThrow();
 expect(()=>validateFiles(Array.from({length:6},()=>new File(['x'],'a.txt')))).toThrow();
 expect(()=>validateFiles([new File(['x'],'발표.pptx')],5)).toThrow();
});
test('upload uses owner folder, random safe name, retains Korean original name',async()=>{
 const files=await uploadFiles([new File(['my work'],'나의 기록.txt')],uid);
 expect(files[0].name).toBe('나의 기록.txt');expect(validAttachments(files)).toBe(true);expect(files[0].path.startsWith(uid+'/')).toBe(true);
 expect(mock.upload.mock.calls[0][2]).toEqual({contentType:'text/plain',upsert:false});
});
test('partial upload failure rolls back already uploaded files',async()=>{
 mock.upload.mockResolvedValueOnce({error:null}).mockResolvedValueOnce({error:{message:'offline'}});
 await expect(uploadFiles([new File(['a'],'a.txt'),new File(['b'],'b.txt')],uid)).rejects.toThrow();
 expect(mock.remove).toHaveBeenCalledTimes(1);expect(mock.remove.mock.calls[0][0]).toHaveLength(1);
});
test('account switch and foreign paths cannot download',async()=>{
 const f={path:uid+'/22222222-2222-4222-8222-222222222222.txt',name:'a.txt',size:1,type:'text/plain'};
 expect(()=>ownedPaths([f],'other')).toThrow();
 mock.getUser.mockResolvedValue({data:{user:{id:'other'}}});await expect(downloadFile(f,uid)).rejects.toThrow();expect(mock.download).not.toHaveBeenCalled();
});
test('invalid imported attachment paths rejected and file metadata excluded from SBT proof',()=>{
 expect(validAttachments([{path:'../../secret',name:'a',size:1,type:'text/plain'}])).toBe(false);
 const p=createProof({id:'a',title:'test',note:'note',date:'2026-11-02',org:'',type:'프로젝트',attachments:[{path:uid+'/22222222-2222-4222-8222-222222222222.txt',name:'private.txt',size:1,type:'text/plain'}]},'0x1111111111111111111111111111111111111111','0x2222222222222222222222222222222222222222');
 expect(p.activity.attachments).toBeUndefined();
});
