import test from 'node:test';
import assert from 'node:assert/strict';
import { fields, getStages, getUnlockedStage, isJourneyComplete, isStageComplete, validCustomRounds } from '../src/roadmap-model.ts';

for (const field of fields) {
  test(`${field}: first three legacy missions unlock deep exploration`, () => {
    const stages = getStages(field);
    assert.equal(stages.length, 4);
    assert.equal(getUnlockedStage(stages, []), 0);
    const legacyDone = stages[0].missions.map(m => field + m.title);
    assert.deepEqual(stages[0].missions.map(m => m.id), legacyDone);
    assert.equal(getUnlockedStage(stages, legacyDone.slice(0, 2)), 0);
    assert.equal(getUnlockedStage(stages, legacyDone), 1);
    assert.equal(isJourneyComplete(stages, legacyDone), false);
  });
  test(`${field}: all four stages complete in order, then next challenge unlocks`, () => {
    let stages = getStages(field);
    const done = [];
    for (let i = 0; i < stages.length; i++) {
      assert.equal(getUnlockedStage(stages, done), i);
      done.push(...stages[i].missions.map(m => m.id));
      assert.equal(isStageComplete(stages[i], done), true);
    }
    assert.equal(isJourneyComplete(stages, done), true);
    const rounds = { [field]: [['인터뷰 두 개 비교하기', '작은 결과물 제작하기', '결과와 배움 정리하기']] };
    // Persist/reload through the same JSON representation as the portfolio.
    const restored = JSON.parse(JSON.stringify({ done, roadmapRounds: rounds }));
    stages = getStages(field, restored.roadmapRounds);
    assert.equal(stages.length, 5);
    assert.equal(getUnlockedStage(stages, restored.done), 4);
    assert.equal(isJourneyComplete(stages, restored.done), false);
    restored.done.push(...stages[4].missions.map(m => m.id));
    assert.equal(isJourneyComplete(stages, restored.done), true);
    rounds[field].push(['새 질문 구체화하기', '다음 실험 실행하기', '피드백 정리하기']);
    assert.equal(getUnlockedStage(getStages(field, rounds), restored.done), 5);
  });
  test(`${field}: undo relocks later stages without deleting their history`, () => {
    const stages = getStages(field);
    const done = stages.flatMap(s => s.missions.map(m => m.id));
    const undone = done.filter(id => id !== stages[0].missions[0].id);
    assert.equal(getUnlockedStage(stages, undone), 0);
    assert.equal(isStageComplete(stages[2], undone), true);
    assert.equal(isJourneyComplete(stages, undone), false);
    undone.push(stages[0].missions[0].id);
    assert.equal(isJourneyComplete(stages, undone), true);
  });
}
test('mission IDs are globally unique and completions do not leak across fields', () => {
  const all = fields.flatMap(f => getStages(f).flatMap(s => s.missions.map(m => m.id)));
  assert.equal(all.length, 72);
  assert.equal(new Set(all).size, all.length);
  const done = getStages(fields[0]).flatMap(s => s.missions.map(m => m.id));
  assert.equal(getUnlockedStage(getStages(fields[1]), done), 0);
});
test('custom rounds are optional for old data and validated on import/save', () => {
  assert.equal(validCustomRounds(undefined), true);
  assert.equal(validCustomRounds({}), true);
  assert.equal(validCustomRounds({[fields[0]]:[['관찰 기록하기','실험 진행하기','회고 작성하기']]}), true);
  for(const invalid of [null, [], {'unknown':[]}, {[fields[0]]:[['미션 하나뿐']]}, {[fields[0]]:[['   ','충분한 길이','충분한 길이']]}, {[fields[0]]:[['가'.repeat(151),'실험하기','기록하기']]}, {[fields[0]]:Array(31).fill(['관찰하기','실험하기','기록하기'])}]) assert.equal(validCustomRounds(invalid), false);
});
test('missing or unsupported interests have no active journey', () => {
  assert.deepEqual(getStages(''), []);
  assert.deepEqual(getStages('__proto__'), []);
  assert.equal(isJourneyComplete([], []), false);
});
