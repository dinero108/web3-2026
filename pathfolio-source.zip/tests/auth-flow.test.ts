// @vitest-environment jsdom
import {createElement} from 'react';
import {cleanup,fireEvent,render,screen,waitFor} from '@testing-library/react';
import {afterEach,beforeEach,expect,test,vi} from 'vitest';
import {readAuthReturn,validPassword} from '../src/auth-feedback';
const mock=vi.hoisted(()=>({signUp:vi.fn(),signInWithPassword:vi.fn(),resend:vi.fn(),verifyOtp:vi.fn(),updateUser:vi.fn(),getSession:vi.fn(),authReturn:{kind:'none',message:undefined} as any}));
vi.mock('../src/supabase',()=>({supabase:{auth:mock},authReturn:mock.authReturn,redirectUrl:()=> 'https://dinero108.github.io/web3-2026/'}));
import AuthDialog from '../src/auth-dialog';
import AuthResult from '../src/auth-result';
beforeEach(()=>{vi.clearAllMocks();mock.authReturn.kind='none';mock.authReturn.message=undefined;mock.signUp.mockResolvedValue({data:{session:null},error:null});mock.resend.mockResolvedValue({error:null});mock.verifyOtp.mockResolvedValue({error:null});});
afterEach(cleanup);
function dialog(recovery=false,initialMode:'login'|'signup'='login'){const close=vi.fn();render(createElement(AuthDialog,{onClose:close,onRecovered:vi.fn(),recovery,initialMode}));return close;}
function fill(label:string,value:string){fireEvent.change(screen.getByLabelText(label,{exact:true}),{target:{value}});}
function submit(){fireEvent.submit(screen.getByRole('dialog').querySelector('form')!);}
test('password policy requires ten characters and all four character groups',()=>{
 for(const password of ['Abcdefg1!','abcdefgh1!','ABCDEFGH1!','Abcdefghi!','Abcdefghi1','Abcdefgh1 '])expect(validPassword(password)).toBe(false);
 expect(validPassword('Abcdefgh1!')).toBe(true);
});
test('signup blocks mismatched confirmation and weak passwords before sending',async()=>{
 dialog(false,'signup');fill('이메일','test@example.invalid');fill('비밀번호','Abcdefgh1!');fill('비밀번호 확인','Different1!');submit();expect(screen.getByRole('status').textContent).toContain('일치하지');expect(mock.signUp).not.toHaveBeenCalled();
 fill('비밀번호','abcdefgh1!');fill('비밀번호 확인','abcdefgh1!');submit();expect(mock.signUp).not.toHaveBeenCalled();
 fill('비밀번호','Abcdefgh1!');fill('비밀번호 확인','Abcdefgh1!');submit();await waitFor(()=>expect(screen.getByRole('heading').textContent).toBe('이메일 인증'));expect(mock.signUp).toHaveBeenCalledTimes(1);expect(screen.queryByLabelText('비밀번호',{exact:true})).toBe(null);
});
test('login preserves compatibility with existing shorter passwords and explains unconfirmed email',async()=>{
 mock.signInWithPassword.mockResolvedValue({error:{code:'email_not_confirmed'}});dialog();fill('이메일','test@example.invalid');fill('비밀번호','oldpass');submit();await waitFor(()=>expect(screen.getByRole('status').textContent).toContain('아직 이메일 인증'));expect(mock.signInWithPassword).toHaveBeenCalled();
});
test('resend uses signup flow and enforces cooldown; OTP verifies selected email',async()=>{
 const close=dialog();fill('이메일','test@example.invalid');fireEvent.click(screen.getByRole('button',{name:'인증 메일 다시 받기'}));await waitFor(()=>expect(screen.getByRole('heading').textContent).toBe('이메일 인증'));expect(mock.resend).toHaveBeenCalledWith({type:'signup',email:'test@example.invalid',options:{emailRedirectTo:'https://dinero108.github.io/web3-2026/'}});await waitFor(()=>expect((screen.getByRole('button',{name:/인증 메일 재발송/}) as HTMLButtonElement).disabled).toBe(true));
 fill('인증번호','12345678');submit();await waitFor(()=>expect(close).toHaveBeenCalled());expect(mock.verifyOtp).toHaveBeenCalledWith({email:'test@example.invalid',token:'12345678',type:'signup'});
});
test('password recovery requires matching strong password too',()=>{
 dialog(true);fill('비밀번호','Abcdefgh1!');fill('비밀번호 확인','Wrongpass1!');submit();expect(mock.updateUser).not.toHaveBeenCalled();expect(screen.getByRole('status').textContent).toContain('일치하지');
});
test('callback parsing keeps errors, distinguishes recovery and retains no token',()=>{
 expect(readAuthReturn('#error=access_denied&error_code=otp_expired','').kind).toBe('error');
 expect(readAuthReturn('#access_token=secret&type=signup','')).toEqual({kind:'signup'});
 expect(readAuthReturn('#access_token=secret&type=recovery','')).toEqual({kind:'recovery'});
 expect(readAuthReturn('','')).toEqual({kind:'none'});
});
test('expired link shows a recovery action rather than silently displaying guest dashboard',()=>{
 mock.authReturn.kind='error';mock.authReturn.message='인증 링크가 만료되었습니다.';const login=vi.fn();render(createElement(AuthResult,{onLogin:login}));expect(screen.getByRole('status').textContent).toContain('만료');fireEvent.click(screen.getByRole('button',{name:'로그인 · 인증 메일 다시 받기'}));expect(login).toHaveBeenCalled();expect(mock.getSession).not.toHaveBeenCalled();
});
test('confirmation succeeds only after the SDK provides a valid session',async()=>{
 mock.authReturn.kind='signup';mock.getSession.mockResolvedValue({data:{session:{user:{id:'test'}}},error:null});render(createElement(AuthResult,{onLogin:vi.fn()}));await waitFor(()=>expect(screen.getByRole('heading').textContent).toBe('이메일 인증이 완료됐어요'));fireEvent.click(screen.getByRole('button',{name:'내 대시보드 시작하기'}));expect(screen.queryByRole('dialog')).toBe(null);
});
test('callback without session displays an error and never claims success',async()=>{
 mock.authReturn.kind='signup';mock.getSession.mockResolvedValue({data:{session:null},error:null});render(createElement(AuthResult,{onLogin:vi.fn()}));await waitFor(()=>expect(screen.getByRole('heading').textContent).toBe('이메일 인증을 확인해 주세요'));
});

test('password visibility toggles independently without submitting or changing values',()=>{
 dialog(false,'signup');fill('비밀번호','Abcdefgh1!');fill('비밀번호 확인','Abcdefgh1!');
 const password=screen.getByLabelText('비밀번호',{exact:true}) as HTMLInputElement;const confirmation=screen.getByLabelText('비밀번호 확인',{exact:true}) as HTMLInputElement;
 expect(password.type).toBe('password');fireEvent.click(screen.getByRole('button',{name:'비밀번호 보기',exact:true}));expect(password.type).toBe('text');expect(confirmation.type).toBe('password');expect(password.value).toBe('Abcdefgh1!');
 fireEvent.click(screen.getByRole('button',{name:'비밀번호 확인 보기',exact:true}));expect(confirmation.type).toBe('text');fireEvent.click(screen.getByRole('button',{name:'비밀번호 숨기기',exact:true}));expect(password.type).toBe('password');expect(mock.signUp).not.toHaveBeenCalled();
});
