// @vitest-environment jsdom
import {createElement} from 'react';
import {render,screen,fireEvent,waitFor,cleanup} from '@testing-library/react';
import {afterEach,expect,test,vi} from 'vitest';
vi.mock('../src/attachment-fields',()=>({ActivityFiles:()=>null}));
import ActivityDetail from '../src/activity-detail';
import {readRoute,routeUrl} from '../src/activity-route';
const activity={id:'first',title:'첫 번째 활동',type:'프로젝트',date:'2026-11-02',org:'학교',note:'배운 내용',attachments:[{path:'retained',name:'a.pdf',size:1,type:'application/pdf'}]};
function setup(save=vi.fn().mockResolvedValue(true)){render(createElement(ActivityDetail,{activity,busy:false,onBusy:vi.fn(),onSave:save,onBack:vi.fn(),onDirty:vi.fn()}));return save;}
afterEach(()=>{cleanup();vi.restoreAllMocks();});
test('detail links roundtrip IDs safely, direct URLs choose the activity view',()=>{const url=routeUrl('activities','a & b/한글');expect(readRoute(url)).toEqual({tab:'activities',activity:'a & b/한글'});expect(readRoute('?tab=unknown')).toEqual({tab:'overview',activity:''});});
test('editing preserves identity and attachments while saving changed fields',async()=>{const save=setup();fireEvent.click(screen.getByRole('button',{name:'기록 수정'}));fireEvent.change(screen.getByLabelText('활동 이름'),{target:{value:'바뀐 활동 이름'}});fireEvent.change(screen.getByLabelText('무엇을 했고, 무엇을 배웠나요?'),{target:{value:'새롭게 배운 내용'}});fireEvent.click(screen.getByRole('button',{name:'수정 내용 저장'}));await waitFor(()=>expect(save).toHaveBeenCalledWith({...activity,title:'바뀐 활동 이름',note:'새롭게 배운 내용'}));await waitFor(()=>expect(screen.queryByRole('button',{name:'수정 내용 저장'})).toBeNull());});
test('failed save keeps draft editable for retry',async()=>{setup(vi.fn().mockResolvedValue(false));fireEvent.click(screen.getByRole('button',{name:'기록 수정'}));fireEvent.change(screen.getByLabelText('활동 이름'),{target:{value:'저장 실패 시 유지'}});fireEvent.click(screen.getByRole('button',{name:'수정 내용 저장'}));await screen.findByText(/저장하지 못했어요/);expect((screen.getByLabelText('활동 이름') as HTMLInputElement).value).toBe('저장 실패 시 유지');});
test('cancel never saves and asks before discarding a draft',()=>{const save=setup();vi.spyOn(window,'confirm').mockReturnValue(true);fireEvent.click(screen.getByRole('button',{name:'기록 수정'}));fireEvent.change(screen.getByLabelText('활동 이름'),{target:{value:'취소할 변경'}});fireEvent.click(screen.getByRole('button',{name:'취소',exact:true}));expect(save).not.toHaveBeenCalled();expect(screen.getByRole('heading',{name:activity.title})).toBeTruthy();});
