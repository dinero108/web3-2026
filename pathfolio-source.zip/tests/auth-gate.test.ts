// @vitest-environment jsdom
import {createElement} from 'react';
import {render,screen,act,cleanup} from '@testing-library/react';
import {afterEach,expect,test,vi} from 'vitest';
const auth=vi.hoisted(()=>({callback:null as null|((event:string,session:any)=>void)}));
vi.mock('../src/supabase',()=>({authReturn:{kind:'none'},supabase:{auth:{onAuthStateChange:(cb:any)=>{auth.callback=cb;return {data:{subscription:{unsubscribe:vi.fn()}}};}}}}));
vi.mock('../src/auth-dialog',()=>({default:({initialMode,recovery}:any)=>createElement('div',null,recovery?'RESET_PASSWORD':initialMode==='signup'?'SIGNUP_FORM':'LOGIN_FORM')}));
vi.mock('../src/auth-result',()=>({default:()=>null}));
import AuthGate from '../src/auth-gate';
afterEach(cleanup);
const child=createElement('div',null,'PRIVATE_DASHBOARD');
test('private screens never mount while loading or signed out',()=>{render(createElement(AuthGate,{children:child}));expect(screen.queryByText('PRIVATE_DASHBOARD')).toBeNull();act(()=>auth.callback!('INITIAL_SESSION',null));expect(screen.getByText('LOGIN_FORM')).toBeTruthy();expect(screen.queryByText('PRIVATE_DASHBOARD')).toBeNull();});
test('confirmed login opens the page and logout immediately removes it',()=>{render(createElement(AuthGate,{children:child}));act(()=>auth.callback!('SIGNED_IN',{user:{id:'one',email_confirmed_at:'2026-11-02'}}));expect(screen.getByText('PRIVATE_DASHBOARD')).toBeTruthy();act(()=>auth.callback!('SIGNED_OUT',null));expect(screen.queryByText('PRIVATE_DASHBOARD')).toBeNull();expect(screen.getByText('LOGIN_FORM')).toBeTruthy();});
test('unconfirmed users cannot enter and signup stays accessible',()=>{render(createElement(AuthGate,{children:child,signup:true}));act(()=>auth.callback!('INITIAL_SESSION',{user:{id:'one'}}));expect(screen.queryByText('PRIVATE_DASHBOARD')).toBeNull();expect(screen.getByText('SIGNUP_FORM')).toBeTruthy();});
test('password recovery shows reset form before granting access',()=>{render(createElement(AuthGate,{children:child}));act(()=>auth.callback!('PASSWORD_RECOVERY',{user:{id:'one',email_confirmed_at:'2026-11-02'}}));expect(screen.getByText('RESET_PASSWORD')).toBeTruthy();expect(screen.queryByText('PRIVATE_DASHBOARD')).toBeNull();});

test('startup deletes legacy guest storage without affecting account auth',()=>{localStorage.setItem('pathfolio.portfolio.v1',JSON.stringify({name:'legacy'}));render(createElement(AuthGate,{children:child}));expect(localStorage.getItem('pathfolio.portfolio.v1')).toBeNull();});
