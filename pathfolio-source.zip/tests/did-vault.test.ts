import 'fake-indexeddb/auto';
import {expect,test} from 'vitest';
import {Wallet} from 'ethers';
import {createVault,didFor,unlockVault,seal,readVault,writeVault,deleteVault,base64,recordMessage,verifyRecord,validateData,type LocalActivity} from '../src/did-vault';
import {challenge,verifyChallenge} from '../src/did-identity';
const password='local-test-password-only';
const activity:LocalActivity={id:'test-record',title:'비공개 프로젝트',note:'내가 기록한 내용',type:'프로젝트',org:'테스트',date:'2026-11-12',files:[{id:'file-1',name:'기록.txt',size:5,type:'text/plain',content:base64(new TextEncoder().encode('hello'))}]};
test('encrypted backup roundtrip includes actual files and rejects wrong password, tampering, or different DID',async()=>{
 const did=didFor(Wallet.createRandom().address);const initial=await createVault(did,password,'별명');const saved=await seal(initial,{name:'별명',activities:[activity]});
 expect(JSON.stringify(saved.envelope)).not.toContain('비공개');expect(JSON.stringify(saved.envelope)).not.toContain(activity.files[0].content);expect(saved.key.extractable).toBe(false);
 const restored=await unlockVault(JSON.parse(JSON.stringify(saved.envelope)),password,did);expect(restored.data).toEqual(saved.data);
 await expect(unlockVault(saved.envelope,'wrong-password',did)).rejects.toThrow('비밀번호');
 await expect(unlockVault(saved.envelope,password,didFor(Wallet.createRandom().address))).rejects.toThrow('지갑');
 await expect(unlockVault({...saved.envelope,revision:saved.envelope.revision+1},password,did)).rejects.toThrow('손상');
 const changed={...saved.envelope,ciphertext:(saved.envelope.ciphertext[0]==='A'?'B':'A')+saved.envelope.ciphertext.slice(1)};
 await expect(unlockVault(changed,password,did)).rejects.toThrow('손상');
},10000);
test('transactional persistence prevents stale tab overwrites, concurrent creation, and stale deletion',async()=>{
 const initial=await createVault(didFor(Wallet.createRandom().address),password,'before');await writeVault(initial.envelope);
 await expect(writeVault(initial.envelope)).rejects.toThrow('다른 탭');
 const a=await seal(initial,{name:'after',activities:[activity]});const stale=await seal(initial,{name:'lost',activities:[]});await writeVault(a.envelope,initial.envelope);
 await expect(writeVault(stale.envelope,initial.envelope)).rejects.toThrow('다른 탭');await expect(deleteVault(initial.envelope)).rejects.toThrow('변경');
 expect((await unlockVault((await readVault(a.envelope.did))!,password,a.envelope.did)).data.name).toBe('after');
 await deleteVault(a.envelope);expect(await readVault(a.envelope.did)).toBeUndefined();
});
test('signed sharing binds text, signer and included file bytes; unsigned edits fail',async()=>{
 const signer=Wallet.createRandom();const data={format:'pathfolio-signed-record' as const,version:1 as const,did:didFor(signer.address),createdAt:new Date().toISOString(),activity};const signature=await signer.signMessage(recordMessage(data));const record={...data,signature};expect(verifyRecord(record)).toEqual(record);
 expect(()=>verifyRecord({...record,activity:{...activity,note:'수정'}})).toThrow();
 expect(()=>verifyRecord({...record,activity:{...activity,files:[]}})).toThrow();
 expect(()=>verifyRecord({...record,activity:{...activity,files:[{...activity.files[0],content:base64(new TextEncoder().encode('world'))}]}})).toThrow();
 expect(()=>verifyRecord({...record,did:didFor(Wallet.createRandom().address)})).toThrow();
});
test('import validation rejects damaged files and duplicate record IDs',()=>{
 expect(()=>validateData({name:'',activities:[activity,activity]})).toThrow();
 expect(()=>validateData({name:'',activities:[{...activity,files:[{...activity.files[0],size:9}]}]})).toThrow();
 expect(()=>validateData({name:'',activities:[{...activity,title:''}]})).toThrow();
});
test('a maximum-size supported attachment validates and survives encryption',async()=>{
 const bytes=new Uint8Array(10*1024*1024);bytes[0]=65;bytes[bytes.length-1]=90;
 const large={...activity,files:[{...activity.files[0],size:bytes.length,content:base64(bytes)}]};
 const data={name:'',activities:[large]};validateData(data);
 const initial=await createVault(didFor(Wallet.createRandom().address),password,'');const saved=await seal(initial,data);
 expect((await unlockVault(saved.envelope,password,saved.envelope.did)).data.activities[0].files[0].content).toBe(large.files[0].content);
},20000);
test('authentication signs an origin-bound fresh nonce and rejects other signer, domain and expiry',async()=>{
 const w=Wallet.createRandom();const now=new Date().toISOString();const message=challenge(w.address,11155111,'pathfolio.dinero.kr','https://pathfolio.dinero.kr/','12345678',now);const signature=await w.signMessage(message);
 expect(()=>verifyChallenge(message,signature,w.address,now)).not.toThrow();
 expect(()=>verifyChallenge(message.replace('pathfolio.dinero.kr','evil.test'),signature,w.address,now)).toThrow();
 expect(()=>verifyChallenge(message,signature,Wallet.createRandom().address,now)).toThrow();
 expect(()=>verifyChallenge(message,signature,w.address,new Date(Date.now()-301000).toISOString())).toThrow();
});
