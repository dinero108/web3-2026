// @vitest-environment jsdom
import {test,expect,vi,afterEach} from 'vitest';
import {render,screen,fireEvent,cleanup} from '@testing-library/react';
import PortfolioLoadState from '../src/portfolio-load-state';
afterEach(cleanup);
test('failed loading is not presented as an empty portfolio and has recovery controls',()=>{const retry=vi.fn(),login=vi.fn();render(<PortfolioLoadState state="auth" onRetry={retry} onLogin={login}/>);expect(screen.getByText(/0개라는 의미는 아닙니다/)).toBeTruthy();fireEvent.click(screen.getByRole('button',{name:'다시 불러오기'}));fireEvent.click(screen.getByRole('button',{name:'다시 로그인'}));expect(retry).toHaveBeenCalledOnce();expect(login).toHaveBeenCalledOnce();});
