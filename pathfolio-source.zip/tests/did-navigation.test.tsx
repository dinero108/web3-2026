// @vitest-environment jsdom
import React from 'react';
import {afterEach,expect,test,vi} from 'vitest';
import {cleanup,fireEvent,render,screen} from '@testing-library/react';
import {ActivityList} from '../src/did-workspace';
import {Overview,WorkspaceNav} from '../src/did-overview';
import type {LocalActivity} from '../src/did-vault';
const activities:LocalActivity[]=[{id:'a',title:'환경 지도 프로젝트',type:'프로젝트',date:'2026-11-01',org:'환경 동아리',note:'협업을 배웠어요.',files:[]},{id:'b',title:'책 읽고 토론하기',type:'독서',date:'2026-11-10',org:'독서 모임',note:'여러 관점을 배웠어요.',files:[]}];
afterEach(cleanup);
test('record search and type filter combine, reset, and date sorting does not mutate stored records',()=>{
 const open=vi.fn();render(<ActivityList activities={activities} busy={false} run={async()=>{}} save={async()=>false} open={open}/>);
 fireEvent.change(screen.getByLabelText('활동 검색'),{target:{value:'환경 동아리'}});expect(screen.queryByRole('heading',{name:'책 읽고 토론하기'})).toBeNull();
 fireEvent.change(screen.getByLabelText('활동 종류 필터'),{target:{value:'독서'}});expect(screen.getByText('찾는 활동이 없어요')).toBeTruthy();
 fireEvent.click(screen.getByRole('button',{name:'검색 조건 지우기'}));fireEvent.change(screen.getByLabelText('활동 정렬'),{target:{value:'date'}});
 const cards=screen.getAllByRole('button').filter(b=>b.classList.contains('dv-activity-card'));expect(cards[0].textContent).toContain('책 읽고 토론하기');fireEvent.click(cards[0]);expect(open).toHaveBeenCalledWith('b');expect(activities[0].id).toBe('a');
});
test('overview presents only actual records and routes to record creation, detail and backup',()=>{
 const go=vi.fn(),open=vi.fn(),backup=vi.fn();render(<Overview data={{name:'테스트',activities}} did="did:pkh:eip155:1:0x1234567890123456789012345678901234567890" go={go} open={open} backup={backup}/>);
 fireEvent.click(screen.getByRole('button',{name:'새로운 활동 기록하기'}));expect(go).toHaveBeenCalledWith('new');
 fireEvent.click(screen.getByRole('button',{name:/환경 지도 프로젝트/}));expect(open).toHaveBeenCalledWith('a');
 fireEvent.click(screen.getByRole('button',{name:/지금 백업하기/}));expect(backup).toHaveBeenCalledOnce();expect(screen.getByText('0 MB / 50 MB')).toBeTruthy();
 expect(screen.queryByText('기관 인증 완료')).toBeNull();
});
test('workspace navigation identifies the current page and is disabled while saving',()=>{
 const go=vi.fn();const {rerender}=render(<WorkspaceNav active="overview" go={go} busy={false}/>);const nav=screen.getByRole('navigation',{name:'주 메뉴'});expect(nav.querySelector('[aria-current="page"]')?.textContent).toContain('나의 보관함');
 fireEvent.click(screen.getByRole('button',{name:/내 DID · 백업/}));expect(go).toHaveBeenCalledWith('profile');rerender(<WorkspaceNav active="profile" go={go} busy={true}/>);expect(screen.getAllByRole('button').every(b=>(b as HTMLButtonElement).disabled)).toBe(true);
});
