// @vitest-environment jsdom
import {expect,test} from 'vitest';
import {commitment,createProof,parseProof,currentWallet,CHAIN_ID} from '../src/sbt-client';
const a={id:'one',title:'독서 프로젝트',type:'독서',date:'2026-11-02',org:'학교',note:'private learning record'};
const address='0x1111111111111111111111111111111111111111',recipient='0x2222222222222222222222222222222222222222';
test('proof hash includes the complete record, recipient, chain, contract and random salt',()=>{
 const p=createProof(a,address,recipient);expect(parseProof(JSON.stringify(p))).toEqual(p);expect(createProof(a,address,recipient).commitment).not.toBe(p.commitment);
 for(const key of ['title','note','date','org','type','id'] as const)expect(()=>parseProof(JSON.stringify({...p,activity:{...a,[key]:a[key]+' changed'}}))).toThrow();
 expect(commitment({...p,recipient:address})).not.toBe(p.commitment);expect(commitment({...p,chainId:1})).not.toBe(p.commitment);expect(commitment({...p,contract:recipient})).not.toBe(p.commitment);
});
test('invalid proof size, salt, unsupported chain and malformed input are rejected',()=>{
 const p=createProof(a,address,recipient);for(const input of ['bad json',JSON.stringify({...p,salt:'0x00'}),JSON.stringify({...p,chainId:1}),' '.repeat(50001)])expect(()=>parseProof(input)).toThrow();
});
test('writes refuse Ethereum mainnet before a signer can be requested',async()=>{
 const calls:string[]=[];(window as any).ethereum={request:async({method}:{method:string})=>{calls.push(method);return '0x1';}};
 await expect(currentWallet()).rejects.toThrow('Sepolia');expect(calls).toEqual(['eth_chainId']);delete (window as any).ethereum;expect(CHAIN_ID).toBe(11155111);
});
