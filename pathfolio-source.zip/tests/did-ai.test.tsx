// @vitest-environment jsdom
import React from 'react';
import {afterEach,beforeEach,expect,test,vi} from 'vitest';
import {cleanup,fireEvent,render,screen,waitFor} from '@testing-library/react';
import {webcrypto} from 'node:crypto';
import {Wallet,verifyMessage} from 'ethers';
import AIRecommendations from '../src/did-ai';
import {aiMessage,validateRecords} from '../src/did-ai-protocol';
import {createVault,seal,unlockVault} from '../src/did-vault';
const identity=vi.hoisted(()=>({sign:vi.fn()}));
vi.mock('../src/did-identity',()=>({signFor:identity.sign,walletError:(e:Error)=>e.message}));
const did='did:pkh:eip155:1:0x1234567890123456789012345678901234567890';
const activities=[{id:'private-uuid',title:'내 활동',type:'프로젝트',date:'2026-11-16',org:'비공개 기관',note:'이름을 지울 내용',files:[{id:'f',name:'private.txt',size:6,type:'text/plain',content:'c2VjcmV0'}]}];
const result={summary:'경험을 확장해 보세요.',caution:'적성 판정이 아닙니다.',recommendations:[{title:'조사하기',reason:'활동을 바탕으로',activityIds:['r1'],nextActivity:'자료 비교',steps:['자료 두 개를 비교해요.'],reflection:'어떤 차이가 있었나요?'}]};
beforeEach(()=>{vi.stubGlobal('crypto',webcrypto);identity.sign.mockReset();identity.sign.mockResolvedValue('signature');vi.stubGlobal('fetch',vi.fn(async(_url,init)=>new Response(JSON.stringify(init?.method==='POST'?result:{ready:true}),{status:200})));});
afterEach(()=>{cleanup();vi.unstubAllGlobals();});
function preview(){fireEvent.click(screen.getByLabelText('내 활동'));fireEvent.click(screen.getByRole('button',{name:'전송 내용 미리보기'}));}
async function consent(){fireEvent.click(screen.getByRole('button',{name:'AI 연결 상태 확인'}));await screen.findByText('AI 연결 준비가 되었어요. 전송할 내용을 확인해 주세요.');fireEvent.click(screen.getByLabelText(/전송 내용을 확인했으며/));}
test('no network on mount or preview, excludes personal fields, resets consent after edit, saves only on request',async()=>{
 const save=vi.fn(async()=>true);render(<AIRecommendations activities={activities} did={did} save={save}/>);preview();expect(fetch).not.toHaveBeenCalled();await consent();fireEvent.change(screen.getByLabelText('전송할 내용 1'),{target:{value:'협업을 배웠어요.'}});expect((screen.getByLabelText(/전송 내용을 확인했으며/) as HTMLInputElement).checked).toBe(false);
 fireEvent.click(screen.getByLabelText(/전송 내용을 확인했으며/));fireEvent.click(screen.getByRole('button',{name:'동의한 내용으로 AI 추천받기'}));await screen.findByText('경험을 확장해 보세요.');
 const request=vi.mocked(fetch).mock.calls.find(([,init])=>init?.method==='POST')!;const body=JSON.parse(request[1]!.body as string);expect(body.records).toEqual([{id:'r1',title:'내 활동',type:'프로젝트',date:'',note:'협업을 배웠어요.'}]);expect(JSON.stringify(body.records)).not.toMatch(/private|비공개|2026-11-16|c2Vj/);expect(save).not.toHaveBeenCalled();fireEvent.click(screen.getByRole('button',{name:'추천 결과를 기기에 저장'}));await waitFor(()=>expect(save).toHaveBeenCalledOnce());
});
test('cancelled signature never sends activity body',async()=>{identity.sign.mockRejectedValue(Error('취소'));render(<AIRecommendations activities={activities} did={did} save={async()=>true}/>);preview();await consent();fireEvent.click(screen.getByRole('button',{name:'동의한 내용으로 AI 추천받기'}));await screen.findByText('취소');expect(vi.mocked(fetch).mock.calls.every(([,init])=>init?.method!=='POST')).toBe(true);});
test('unmount while awaiting wallet never sends payload',async()=>{let done:(s:string)=>void=()=>{};identity.sign.mockImplementation(()=>new Promise<string>(r=>{done=r;}));const view=render(<AIRecommendations activities={activities} did={did} save={async()=>true}/>);preview();await consent();fireEvent.click(screen.getByRole('button',{name:'동의한 내용으로 AI 추천받기'}));view.unmount();done('signature');await Promise.resolve();expect(vi.mocked(fetch).mock.calls.every(([,init])=>init?.method!=='POST')).toBe(true);});
test('unconfigured endpoint keeps recommendation disabled without mock result',async()=>{vi.mocked(fetch).mockResolvedValue(new Response(JSON.stringify({ready:false})));render(<AIRecommendations activities={activities} did={did} save={async()=>true}/>);preview();fireEvent.click(screen.getByRole('button',{name:'AI 연결 상태 확인'}));await screen.findByText(/AI 연결 준비 중입니다/);expect(screen.queryByText('경험을 확장해 보세요.')).toBeNull();expect((screen.getByRole('button',{name:'동의한 내용으로 AI 추천받기'}) as HTMLButtonElement).disabled).toBe(true);});
test('request binds reviewed content, timestamps and wallet; rejects attachment injection',async()=>{const wallet=new Wallet('0x'+'11'.repeat(32));const records=validateRecords([{id:'r1',title:'활동',type:'프로젝트',date:'',note:'내용'}]);const stamp=new Date().toISOString();const signature=await wallet.signMessage(aiMessage(wallet.address,stamp,records));expect(verifyMessage(aiMessage(wallet.address,stamp,records),signature)).toBe(wallet.address);expect(verifyMessage(aiMessage(wallet.address,stamp,[{...records[0],note:'변경'}]),signature)).not.toBe(wallet.address);expect(()=>validateRecords([{...records[0],files:[]}])).toThrow();});
test('AI result survives encrypted backup while old vault format still opens',async()=>{const old=await createVault(did,'a-long-test-password','테스트');expect((await unlockVault(old.envelope,'a-long-test-password',did)).data.aiRecommendation).toBeUndefined();const data={...old.data,aiRecommendation:{createdAt:new Date().toISOString(),records:[{id:'r1',title:'활동',type:'프로젝트',date:'',note:'내용'}],result}};const next=await seal(old,data);expect(JSON.stringify(next.envelope)).not.toContain(result.summary);expect((await unlockVault(next.envelope,'a-long-test-password',did)).data.aiRecommendation).toEqual(data.aiRecommendation);});
