// @vitest-environment jsdom
import {afterEach,expect,test,vi} from 'vitest';
import {render,screen,act,cleanup} from '@testing-library/react';
const {request}=vi.hoisted(()=>({request:vi.fn()}));
vi.mock('../src/sharing-client',()=>({sharedRequest:request,downloadShared:vi.fn()}));
import SharedActivity from '../src/shared-activity';
const record={title:'공유 기록',type:'독서',date:'2026-11-02',org:'',note:'본문',files:[]};
afterEach(()=>{cleanup();vi.useRealTimers();vi.resetAllMocks();});
test('slow public refresh never overlaps with another request and revocation removes content',async()=>{
 vi.useFakeTimers();let resolve:any;
 request.mockImplementationOnce(()=>new Promise(r=>{resolve=r})).mockRejectedValueOnce(Error('비공개로 변경됨'));
 render(<SharedActivity token="token"/>);
 await act(async()=>{await vi.advanceTimersByTimeAsync(90000);});
 expect(request).toHaveBeenCalledTimes(1);
 await act(async()=>{resolve({json:async()=>record});});
 expect(screen.getByRole('heading',{name:'공유 기록'})).toBeTruthy();
 await act(async()=>{await vi.advanceTimersByTimeAsync(30000);});
 expect(request).toHaveBeenCalledTimes(2);
 expect(screen.queryByRole('heading',{name:'공유 기록'})).toBeNull();
 expect(screen.getByRole('alert').textContent).toBe('비공개로 변경됨');
});
test('changing shared link immediately hides content from the previous link',async()=>{
 request.mockResolvedValueOnce({json:async()=>record}).mockImplementationOnce(()=>new Promise(()=>{}));
 const view=render(<SharedActivity token="old"/>);await screen.findByRole('heading',{name:'공유 기록'});
 view.rerender(<SharedActivity token="new"/>);
 expect(screen.queryByRole('heading',{name:'공유 기록'})).toBeNull();
 expect(screen.getByRole('status').textContent).toContain('불러오는 중');
});
