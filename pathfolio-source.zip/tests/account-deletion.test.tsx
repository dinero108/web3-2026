// @vitest-environment jsdom
import {afterEach,expect,test,vi} from 'vitest';
import {render,screen,fireEvent,cleanup} from '@testing-library/react';
const {invoke,signOut}=vi.hoisted(()=>({invoke:vi.fn(),signOut:vi.fn()}));
vi.mock('../src/supabase',()=>({supabase:{functions:{invoke},auth:{signOut}}}));
import AccountDeletion from '../src/account-deletion';
afterEach(()=>{cleanup();vi.resetAllMocks();});
test('deletion requires password, typed confirmation and acknowledgement',()=>{
 render(<AccountDeletion disabled={false} onBusy={()=>{}}/>);fireEvent.click(screen.getByText('회원탈퇴 안내 보기'));
 const submit=screen.getByRole('button',{name:'계정 영구 삭제'}) as HTMLButtonElement;
 expect(submit.disabled).toBe(true);fireEvent.change(screen.getByLabelText('현재 비밀번호'),{target:{value:'test-password'}});
 fireEvent.change(screen.getByLabelText('확인을 위해 ‘탈퇴’를 입력해 주세요'),{target:{value:'탈퇴'}});expect(submit.disabled).toBe(true);
 fireEvent.click(screen.getByRole('checkbox'));expect(submit.disabled).toBe(false);expect(invoke).not.toHaveBeenCalled();
 fireEvent.click(screen.getByRole('button',{name:'취소',exact:true}));fireEvent.click(screen.getByText('회원탈퇴 안내 보기'));
 expect((screen.getByLabelText('현재 비밀번호') as HTMLInputElement).value).toBe('');
});
test('failed deletion preserves retry option, clears password and does not sign out',async()=>{
 invoke.mockResolvedValue({error:{context:{json:async()=>({error:'남은 파일을 정리하려면 다시 요청해 주세요.'})}}});const busy=vi.fn();
 render(<AccountDeletion disabled={false} onBusy={busy}/>);fireEvent.click(screen.getByText('회원탈퇴 안내 보기'));
 fireEvent.change(screen.getByLabelText('현재 비밀번호'),{target:{value:'test-password'}});fireEvent.change(screen.getByLabelText('확인을 위해 ‘탈퇴’를 입력해 주세요'),{target:{value:'탈퇴'}});fireEvent.click(screen.getByRole('checkbox'));fireEvent.click(screen.getByRole('button',{name:'계정 영구 삭제'}));
 expect((await screen.findByRole('alert')).textContent).toContain('남은 파일');expect(signOut).not.toHaveBeenCalled();expect(busy).toHaveBeenLastCalledWith(false);expect((screen.getByLabelText('현재 비밀번호') as HTMLInputElement).value).toBe('');
});
