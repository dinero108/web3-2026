// @vitest-environment jsdom
import {afterEach,expect,test,vi} from 'vitest';
import {render,screen,fireEvent,cleanup} from '@testing-library/react';
import Profile from '../src/profile';
import {readRoute} from '../src/activity-route';
vi.mock('../src/supabase',()=>({supabase:{}}));
const data={name:'별명',interests:[],done:[],activities:[{id:'one',title:'기록',type:'독서',note:'배움',date:'2026-11-02',org:''}]};
function props(){return {data,user:{id:'owner',email:'owner@example.test',email_confirmed_at:'2026-11-01',created_at:'2026-11-01'} as any,ready:true,busy:false,save:vi.fn(async()=>true),onBusy:vi.fn(),onDirty:vi.fn(),onExport:vi.fn(),onPassword:vi.fn(),onPortfolio:vi.fn()};}
afterEach(cleanup);
test('profile route supports direct links and refresh',()=>{expect(readRoute('?tab=profile')).toEqual({tab:'profile',activity:''});});
test('name update preserves existing activity data and warns on unsaved changes',async()=>{const p=props();render(<Profile {...p}/>);fireEvent.change(screen.getByLabelText('표시할 이름 또는 별명'),{target:{value:'새 이름'}});expect(p.onDirty).toHaveBeenLastCalledWith(true);expect((screen.getByRole('button',{name:'회원탈퇴 안내 보기'}) as HTMLButtonElement).disabled).toBe(true);fireEvent.click(screen.getByRole('button',{name:'프로필 저장'}));await screen.findByText('프로필을 저장했어요.');expect(p.save).toHaveBeenCalledWith({...data,name:'새 이름'});});
test('failed save preserves the draft and cancel restores the saved name',async()=>{const p=props();p.save.mockResolvedValue(false);render(<Profile {...p}/>);fireEvent.change(screen.getByLabelText('표시할 이름 또는 별명'),{target:{value:'수정 중'}});fireEvent.click(screen.getByRole('button',{name:'프로필 저장'}));await screen.findByText('저장하지 못했어요. 입력한 이름은 그대로 유지됩니다.');expect((screen.getByLabelText('표시할 이름 또는 별명') as HTMLInputElement).value).toBe('수정 중');fireEvent.click(screen.getByRole('button',{name:'변경 취소'}));expect((screen.getByLabelText('표시할 이름 또는 별명') as HTMLInputElement).value).toBe('별명');expect(p.onDirty).toHaveBeenLastCalledWith(false);});
test('profile offers password reset, backup and portfolio navigation',()=>{const p=props();render(<Profile {...p}/>);for(const [label,fn] of [['비밀번호 재설정',p.onPassword],['기록 백업 내려받기',p.onExport],['포트폴리오 · 기록 가져오기 →',p.onPortfolio]] as const){fireEvent.click(screen.getByRole('button',{name:label}));expect(fn).toHaveBeenCalledTimes(1);}});
test('profile cannot overwrite records before loading has completed',()=>{const p=props();render(<Profile {...p} ready={false}/>);expect((screen.getByLabelText('표시할 이름 또는 별명') as HTMLInputElement).disabled).toBe(true);expect((screen.getByRole('button',{name:'프로필 저장'}) as HTMLButtonElement).disabled).toBe(true);expect((screen.getByRole('button',{name:'기록 백업 내려받기'}) as HTMLButtonElement).disabled).toBe(true);});
