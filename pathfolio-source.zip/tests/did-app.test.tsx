// @vitest-environment jsdom
import React from 'react';
import 'fake-indexeddb/auto';
import {webcrypto} from 'node:crypto';
import {afterEach,beforeEach,expect,test,vi} from 'vitest';
import {render,screen,fireEvent,cleanup,waitFor} from '@testing-library/react';

import {didFor,readVault,unlockVault} from '../src/did-vault';
const identity=vi.hoisted(()=>({did:'',events:new Map<string,()=>void>()}));
vi.mock('../src/did-identity',()=>({identify:vi.fn(async()=>identity.did),walletError:(e:Error)=>e.message,provider:()=>({on:(n:string,f:()=>void)=>identity.events.set(n,f),removeListener:(n:string)=>identity.events.delete(n)}),signFor:vi.fn()}));
import DIDApp from '../src/did-app';
beforeEach(()=>{vi.stubGlobal('crypto',webcrypto);vi.stubGlobal('fetch',vi.fn(()=>Promise.reject(Error('Unexpected network'))));identity.did=didFor('0x1234567890123456789012345678901234567890');history.replaceState(null,'','/');});
afterEach(()=>{cleanup();vi.unstubAllGlobals();});
test('wallet gate, encrypted activity/file CRUD, locking and reopening work without network',async()=>{
 render(<DIDApp/>);expect(screen.queryByRole('button',{name:'활동 기록 추가'})).toBeNull();
 fireEvent.click(screen.getByRole('button',{name:'MetaMask로 DID 확인'}));await screen.findByLabelText('이름 또는 별명');
 fireEvent.change(screen.getByLabelText('이름 또는 별명'),{target:{value:'보관함 테스트'}});
 fireEvent.change(screen.getByLabelText('보관함 비밀번호 (12자 이상)'),{target:{value:'my-test-password-12'}});
 fireEvent.change(screen.getByLabelText('비밀번호 확인'),{target:{value:'my-test-password-12'}});
 fireEvent.click(screen.getByRole('checkbox'));fireEvent.click(screen.getByRole('button',{name:'새 보관함 만들기'}));
 await screen.findByRole('button',{name:'활동 기록 추가'});fireEvent.click(screen.getByRole('button',{name:'활동 기록 추가'}));
 fireEvent.change(screen.getByLabelText('활동 이름'),{target:{value:'테스트 활동'}});fireEvent.change(screen.getByLabelText('활동 내용과 배운 점'),{target:{value:'기기에서만 읽는 내용'}});
 const file=new File(['hello'],'증거.txt',{type:'text/plain'});Object.defineProperty(file,'arrayBuffer',{value:async()=>new TextEncoder().encode('hello').buffer});
 fireEvent.change(screen.getByLabelText('첨부파일 · 활동당 5개 / 파일당 10MB'),{target:{files:[file]}});
 await screen.findByText('증거.txt');await waitFor(()=>expect((screen.getByRole('button',{name:'암호화해 저장'}) as HTMLButtonElement).disabled).toBe(false));
 fireEvent.click(screen.getByRole('button',{name:'암호화해 저장'}));await screen.findByRole('button',{name:'기록 수정'});expect(screen.getByText('기기에서만 읽는 내용')).toBeTruthy();
 fireEvent.click(screen.getByRole('button',{name:'기록 수정'}));fireEvent.change(screen.getByLabelText('활동 이름'),{target:{value:'수정한 활동'}});fireEvent.click(screen.getByRole('button',{name:'암호화해 저장'}));await screen.findByRole('heading',{name:'수정한 활동'});
 fireEvent.click(screen.getByRole('button',{name:'잠그기'}));expect(screen.queryByText('기기에서만 읽는 내용')).toBeNull();
 fireEvent.click(screen.getByRole('button',{name:'MetaMask로 DID 확인'}));await screen.findByLabelText('보관함 비밀번호 (12자 이상)');fireEvent.change(screen.getByLabelText('보관함 비밀번호 (12자 이상)'),{target:{value:'my-test-password-12'}});fireEvent.click(screen.getByRole('button',{name:'보관함 열기'}));await screen.findByRole('heading',{name:'수정한 활동'});
 const encrypted=(await readVault(identity.did))!;expect(JSON.stringify(encrypted)).not.toContain('테스트');const restored=await unlockVault(encrypted,'my-test-password-12',identity.did);expect(restored.data.activities[0].files[0].content).toBe('aGVsbG8=');expect(fetch).not.toHaveBeenCalled();
 identity.events.get('accountsChanged')!();await screen.findByRole('button',{name:'MetaMask로 DID 확인'});expect(screen.queryByText('기기에서만 읽는 내용')).toBeNull();
},15000);
