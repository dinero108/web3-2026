import {expect,test} from 'vitest';
import {isPortfolio,parsePortfolio,MAX_BACKUP_BYTES} from '../src/portfolio-storage';
const activity={id:'a',title:'기록',type:'프로젝트',date:'2026-11-02',org:'',note:'내용'};
const portfolio={name:'나',interests:[],done:[],activities:[activity]};
test('large Korean backup exported with indentation can be imported again',()=>{
 const data={...portfolio,activities:Array.from({length:30},(_,i)=>({...activity,id:String(i),note:'가'.repeat(3000)}))};
 const backup=JSON.stringify(data,null,2);
 expect(new TextEncoder().encode(backup).length).toBeGreaterThan(100000);
 expect(new TextEncoder().encode(backup).length).toBeLessThan(MAX_BACKUP_BYTES);
 expect(parsePortfolio(backup)).toEqual(data);
});
test('duplicate and empty activity IDs cannot confuse detail and sharing routes',()=>{
 expect(isPortfolio({...portfolio,activities:[activity,activity]})).toBe(false);
 expect(isPortfolio({...portfolio,activities:[{...activity,id:' '}]})).toBe(false);
});
test('larger import envelope does not bypass account storage limit',()=>{
 const data={...portfolio,activities:Array.from({length:40},(_,i)=>({...activity,id:String(i),note:'가'.repeat(3000)}))};
 expect(()=>parsePortfolio(JSON.stringify(data))).toThrow('용량');
});
