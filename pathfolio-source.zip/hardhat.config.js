export default {networks:{test:{type:'edr-simulated',chainType:'l1',chainId:31337}}};
