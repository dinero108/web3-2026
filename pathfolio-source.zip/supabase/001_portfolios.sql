create table public.portfolios (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null check (jsonb_typeof(data) = 'object' and octet_length(data::text) <= 400000),
  updated_at timestamptz not null default now()
);
alter table public.portfolios enable row level security;
revoke all on public.portfolios from anon, authenticated;
grant select, insert, update, delete on public.portfolios to authenticated;
create policy own_select on public.portfolios for select to authenticated using ((select auth.uid()) = user_id);
create policy own_insert on public.portfolios for insert to authenticated with check ((select auth.uid()) = user_id);
create policy own_update on public.portfolios for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy own_delete on public.portfolios for delete to authenticated using ((select auth.uid()) = user_id);
create function public.touch_portfolio() returns trigger language plpgsql set search_path = '' as $$ begin new.updated_at = now(); return new; end $$;
create trigger touch_portfolio before update on public.portfolios for each row execute function public.touch_portfolio();
