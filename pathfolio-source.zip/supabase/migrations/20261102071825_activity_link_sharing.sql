create table public.activity_shares (
 user_id uuid not null references public.portfolios(user_id) on delete cascade,
 activity_id text not null check (char_length(activity_id) between 1 and 150),
 token uuid not null default gen_random_uuid() unique,
 file_paths text[] not null default '{}' check(cardinality(file_paths)<=5),
 created_at timestamptz not null default now(),
 primary key(user_id,activity_id)
);
alter table public.activity_shares enable row level security;
revoke all on public.activity_shares from anon;
grant select,insert,update,delete on public.activity_shares to authenticated;
create policy shares_own_select on public.activity_shares for select to authenticated using(user_id=(select auth.uid()));
create policy shares_own_insert on public.activity_shares for insert to authenticated with check(user_id=(select auth.uid()) and exists(select 1 from public.portfolios p, lateral jsonb_array_elements(case when jsonb_typeof(p.data->'activities')='array' then p.data->'activities' else '[]'::jsonb end) a where p.user_id=(select auth.uid()) and a->>'id'=activity_id));
create policy shares_own_update on public.activity_shares for update to authenticated using(user_id=(select auth.uid())) with check(user_id=(select auth.uid()));
create policy shares_own_delete on public.activity_shares for delete to authenticated using(user_id=(select auth.uid()));
create schema if not exists private;
create function private.prune_activity_shares() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 delete from public.activity_shares s where s.user_id=new.user_id and not exists(select 1 from jsonb_array_elements(case when jsonb_typeof(new.data->'activities')='array' then new.data->'activities' else '[]'::jsonb end) a where a->>'id'=s.activity_id);
 return new;
end;$$;
revoke all on function private.prune_activity_shares() from public;
create trigger prune_activity_shares after update of data on public.portfolios for each row execute function private.prune_activity_shares();
