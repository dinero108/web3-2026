create table public.activity_recommendations (
 user_id uuid primary key references public.portfolios(user_id) on delete cascade,
 fingerprint text,
 result jsonb,
 requested_at timestamptz not null,
 day date not null,
 attempts integer not null check(attempts between 1 and 5)
);
alter table public.activity_recommendations enable row level security;
revoke all on public.activity_recommendations from public, anon, authenticated;
grant select, insert, update, delete on public.activity_recommendations to service_role;
comment on table public.activity_recommendations is 'Server-only AI cache and atomic per-user request quota. Accessible only through authenticated activity-recommendations Edge Function.';
