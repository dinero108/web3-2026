create table public.account_deletions (
 user_id uuid primary key references auth.users(id) on delete cascade,
 started_at timestamptz not null default now()
);
alter table public.account_deletions enable row level security;
revoke all on public.account_deletions from public,anon,authenticated;
grant all on public.account_deletions to service_role;
create or replace function private.account_is_active()
returns boolean language sql stable security definer set search_path=''
as $$ select auth.uid() is not null
 and exists(select 1 from auth.users u where u.id=auth.uid())
 and not exists(select 1 from public.account_deletions d where d.user_id=auth.uid()) $$;
revoke all on function private.account_is_active() from public,anon;
grant usage on schema private to authenticated;
grant execute on function private.account_is_active() to authenticated;
create policy active_account_only on public.portfolios as restrictive for all to authenticated
using ((select private.account_is_active())) with check ((select private.account_is_active()));
create policy active_account_only on public.activity_shares as restrictive for all to authenticated
using ((select private.account_is_active())) with check ((select private.account_is_active()));
create policy active_account_only on storage.objects as restrictive for all to authenticated
using ((select private.account_is_active())) with check ((select private.account_is_active()));
create function public.begin_account_deletion(target_user uuid)
returns void language plpgsql security invoker set search_path='' as $$
begin
 insert into public.account_deletions(user_id) values(target_user) on conflict do nothing;
 delete from public.activity_shares where user_id=target_user;
end $$;
revoke all on function public.begin_account_deletion(uuid) from public,anon,authenticated;
grant execute on function public.begin_account_deletion(uuid) to service_role;
create function public.account_deletion_files(target_user uuid)
returns table(bucket_id text,name text) language sql stable security invoker set search_path='' as $$
 select o.bucket_id,o.name from storage.objects o
 where o.owner_id=target_user::text or (o.bucket_id='activity-files' and starts_with(o.name,target_user::text||'/'))
 order by o.bucket_id,o.name limit 100
$$;
revoke all on function public.account_deletion_files(uuid) from public,anon,authenticated;
grant execute on function public.account_deletion_files(uuid) to service_role;
