create schema if not exists private;
create table if not exists private.did_ai_usage (
 subject text primary key,
 day date not null,
 attempts integer not null,
 last_request timestamptz not null,
 last_issued timestamptz not null
);
alter table private.did_ai_usage enable row level security;
revoke all on private.did_ai_usage from public, anon, authenticated;
create or replace function public.claim_did_ai_request(p_wallet text,p_issued timestamptz)
returns boolean language plpgsql security definer set search_path='' as $$
declare w private.did_ai_usage; g private.did_ai_usage; now_at timestamptz:=clock_timestamp(); today date:=(now_at at time zone 'UTC')::date;
begin
 if p_wallet !~ '^[a-f0-9]{64}$' or p_issued < now_at-interval '5 minutes' or p_issued > now_at+interval '30 seconds' then return false; end if;
 perform pg_advisory_xact_lock(1414213562);
 delete from private.did_ai_usage where last_request < now_at-interval '7 days';
 select * into w from private.did_ai_usage where subject=p_wallet;
 select * into g from private.did_ai_usage where subject='global';
 if w.subject is not null and (p_issued<=w.last_issued or w.last_request>now_at-interval '1 minute' or (w.day=today and w.attempts>=5)) then return false; end if;
 if g.subject is not null and g.day=today and g.attempts>=20 then return false; end if;
 insert into private.did_ai_usage values(p_wallet,today,1,now_at,p_issued) on conflict(subject) do update set day=today,attempts=case when did_ai_usage.day=today then did_ai_usage.attempts+1 else 1 end,last_request=now_at,last_issued=p_issued;
 insert into private.did_ai_usage values('global',today,1,now_at,p_issued) on conflict(subject) do update set day=today,attempts=case when did_ai_usage.day=today then did_ai_usage.attempts+1 else 1 end,last_request=now_at,last_issued=p_issued;
 return true;
end $$;
revoke all on function public.claim_did_ai_request(text,timestamptz) from public,anon,authenticated;
grant execute on function public.claim_did_ai_request(text,timestamptz) to service_role;
