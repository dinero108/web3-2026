export type RecordInput={id:string;title:string;type:string;date:string;note:string};
export function prepareRecords(input:unknown):RecordInput[]{
 if(!Array.isArray(input))return [];
 return input.filter(a=>a&&typeof a.id==='string'&&typeof a.title==='string'&&typeof a.note==='string').sort((a,b)=>String(b.date).localeCompare(String(a.date))).slice(0,30).map(a=>({id:a.id,title:a.title.slice(0,150),type:String(a.type).slice(0,30),date:String(a.date).slice(0,10),note:a.note.slice(0,1500)}));
}
const text={type:'string'};
export const schema={type:'object',additionalProperties:false,required:['summary','recommendations','caution'],properties:{summary:text,caution:text,recommendations:{type:'array',minItems:1,maxItems:3,items:{type:'object',additionalProperties:false,required:['title','reason','activityIds','nextActivity','steps','reflection'],properties:{title:text,reason:text,activityIds:{type:'array',minItems:1,maxItems:5,items:text},nextActivity:text,steps:{type:'array',minItems:1,maxItems:4,items:text},reflection:text}}}}};
export function validateResult(value:any,records:RecordInput[]){
 const str=(s:unknown)=>typeof s==='string'&&s.trim().length>0&&s.length<=2500;
 const ids=new Set(records.map(a=>a.id));
 if(!value||!str(value.summary)||!str(value.caution)||!Array.isArray(value.recommendations)||!value.recommendations.length||value.recommendations.length>3)throw Error('invalid_result');
 for(const r of value.recommendations){if(!r||![r.title,r.reason,r.nextActivity,r.reflection].every(str)||!Array.isArray(r.activityIds)||!r.activityIds.length||r.activityIds.length>5||!r.activityIds.every((id:unknown)=>typeof id==='string'&&ids.has(id))||!Array.isArray(r.steps)||!r.steps.length||r.steps.length>4||!r.steps.every(str))throw Error('invalid_result');}
 return {summary:value.summary,caution:value.caution,recommendations:value.recommendations.map((r:any)=>({title:r.title,reason:r.reason,activityIds:[...new Set(r.activityIds)],nextActivity:r.nextActivity,steps:r.steps,reflection:r.reflection}))};
}
