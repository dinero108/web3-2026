import {createClient} from 'npm:@supabase/supabase-js@2.118.0';
import {deleteAccountHandler} from './handler.ts';
const options={auth:{persistSession:false,autoRefreshToken:false}};
Deno.serve(deleteAccountHandler({
 client:()=>createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!,options),
 admin:()=>createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,options)
}));
