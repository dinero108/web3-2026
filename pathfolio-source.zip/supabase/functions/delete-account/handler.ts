type Dependencies={client:()=>any;admin:()=>any};
const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,apikey,content-type,x-client-info','Access-Control-Allow-Methods':'POST,OPTIONS','Content-Type':'application/json','Cache-Control':'no-store'};
const reply=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers});
export function deleteAccountHandler(deps:Dependencies){return async(req:Request)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers});
 if(req.method!=='POST')return reply({error:'지원하지 않는 요청입니다.'},405);
 let begun=false;
 try{
  const token=req.headers.get('Authorization')?.replace(/^Bearer /,'');
  if(!token||!req.headers.get('Authorization')?.startsWith('Bearer '))return reply({error:'다시 로그인한 뒤 탈퇴해 주세요.'},401);
  const client=deps.client();
  const {data:{user},error}=await client.auth.getUser(token);
  if(error||!user?.email_confirmed_at||!user.email||user.is_anonymous)return reply({error:'다시 로그인한 뒤 탈퇴해 주세요.'},401);
  const raw=await req.text();if(raw.length>2048)return reply({error:'잘못된 요청입니다.'},400);
  let body;try{body=JSON.parse(raw);}catch{return reply({error:'잘못된 요청입니다.'},400);}
  if(body?.confirmation!=='탈퇴'||body?.acknowledged!==true||typeof body.password!=='string'||!body.password||body.password.length>128)return reply({error:'현재 비밀번호와 탈퇴 확인을 입력해 주세요.'},400);
  // Derive both identity and email from the verified token, never from caller input.
  const {data:verified,error:passwordError}=await client.auth.signInWithPassword({email:user.email,password:body.password});
  if(passwordError||verified.user?.id!==user.id){return reply({error:passwordError?.status===429?'본인 확인 요청이 많아요. 잠시 후 다시 시도해 주세요.':'현재 비밀번호를 확인해 주세요.'},passwordError?.status===429?429:403);}
  const admin=deps.admin();
  const {error:lockError}=await admin.rpc('begin_account_deletion',{target_user:user.id});
  if(lockError)throw Error('lock');begun=true;
  // Storage API removes the actual object; SQL is used only to list exact owned paths.
  for(let batch=0;batch<20;batch++){
   const {data:files,error:listError}=await admin.rpc('account_deletion_files',{target_user:user.id});
   if(listError)throw Error('list');
   if(!Array.isArray(files))throw Error('list');
   if(files.length===0){
    const {error:deleteError}=await admin.auth.admin.deleteUser(user.id);
    if(deleteError)throw Error('delete');
    return reply({deleted:true});
   }
   for(const bucket of new Set<string>(files.map((f:any)=>f.bucket_id))){
    const {error:removeError}=await admin.storage.from(bucket).remove(files.filter((f:any)=>f.bucket_id===bucket).map((f:any)=>f.name));
    if(removeError)throw Error('storage');
   }
  }
  throw Error('remaining');
 }catch{return reply({error:begun?'탈퇴를 아직 완료하지 못했어요. 공유 링크와 기록 변경은 차단했으며, 일부 파일이 삭제되었을 수 있습니다. 같은 비밀번호로 회원탈퇴를 다시 요청하면 남은 정리를 이어갑니다.':'탈퇴를 시작하지 못했어요. 연결 상태를 확인하고 다시 시도해 주세요.'},503);}
};}
