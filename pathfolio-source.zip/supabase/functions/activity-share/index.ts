import {createClient} from 'npm:@supabase/supabase-js@2.118.0';
import {publicRecord,validToken} from './policy.ts';
const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'content-type,apikey,authorization,x-client-info','Access-Control-Allow-Methods':'POST,OPTIONS','Cache-Control':'no-store, max-age=0','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};
const answer=(body:unknown,status=200)=>new Response(JSON.stringify(body),{status,headers:{...headers,'Content-Type':'application/json'}});
Deno.serve(async(req:Request)=>{
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return answer({error:'Method not allowed'},405);
 try{
  const raw=await req.text();if(raw.length>2048)return answer({error:'Invalid request'},400);
  const {token,file}=JSON.parse(raw);if(!validToken(token)||(file!==undefined&&(typeof file!=='string'||!/^[0-9a-f-]{36}\.[a-z0-9]+$/i.test(file))))return answer({error:'Invalid request'},400);
  const client=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:share,error:sError}=await client.from('activity_shares').select('user_id,activity_id,file_paths').eq('token',token).maybeSingle();
  if(sError)return answer({error:'Unavailable'},503);if(!share)return answer({error:'Not found'},404);
  const {data:row,error:pError}=await client.from('portfolios').select('data').eq('user_id',share.user_id).maybeSingle();
  if(pError)return answer({error:'Unavailable'},503);
  const record=publicRecord(share,row?.data);if(!record)return answer({error:'Not found'},404);
  if(file===undefined)return answer(record.activity);
  const attachment=record.files.find((f:any)=>f.path.split('/')[1]===file);if(!attachment)return answer({error:'Not found'},404);
  const {data:blob,error}=await client.storage.from('activity-files').download(attachment.path);if(error||!blob)return answer({error:'Not found'},404);
  // Recheck publication after fetching, so a concurrent revocation cannot hand out a new download.
  const {data:latest}=await client.from('activity_shares').select('file_paths').eq('token',token).maybeSingle();
  if(!latest?.file_paths.includes(attachment.path))return answer({error:'Not found'},404);
  return new Response(blob,{headers:{...headers,'Content-Type':'application/octet-stream','Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(attachment.name)}});
 }catch{return answer({error:'Unable to load share'},400);}
});
