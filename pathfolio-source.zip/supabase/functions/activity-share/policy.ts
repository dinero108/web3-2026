export const validToken=(v:unknown):v is string=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
export function publicRecord(share:any,portfolio:any){
 const activity=Array.isArray(portfolio?.activities)?portfolio.activities.find((a:any)=>a.id===share.activity_id):null;
 if(!activity)return null;
 const files=(Array.isArray(activity.attachments)?activity.attachments:[]).filter((f:any)=>typeof f.path==='string'&&f.path.startsWith(share.user_id+'/')&&share.file_paths.includes(f.path)&&typeof f.name==='string'&&f.size>0&&f.size<=10485760);
 return {activity:{title:activity.title,type:activity.type,date:activity.date,org:activity.org,note:activity.note,files:files.map((f:any)=>({id:f.path.split('/')[1],name:f.name,size:f.size}))},files};
}
