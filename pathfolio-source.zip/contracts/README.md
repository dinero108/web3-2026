# 패스폴리오 SBT — Sepolia 테스트넷

이 구현은 **본인 기록의 무결성 확인용**입니다. 학교/기관 인증, 활동 사실의 진위, 입시용 공인 증명은 보증하지 않습니다. 메인넷 운영 전 별도 보안 검토가 필요합니다.

## 구성

- `contracts/PathfolioSBT.sol`: OpenZeppelin ERC721 기반, ERC5192 `locked` 지원.
- `src/sbt-client.ts`: Sepolia(11155111)만 허용. 배포 코드 일치 확인, 지갑 연결 및 검증 파일 처리.
- `src/sbt-panel.tsx`: 배포 / 본인 발급 / 검증 파일 다운로드 / 검증 / 취소.
- `src/generated/pathfolio-sbt.json`: 고정 컴파일러로 생성된 ABI, 생성 코드, 실행 코드.
- `contracts/compiler-input.json`: 블록 탐색기의 Standard JSON 검증용 입력. 정확한 컴파일러 버전은 artifact의 compiler 필드 확인.

## 배포 완료 (2026-11-02)

- 네트워크: Sepolia (11155111)
- 주소: `0x86E9162216353DC5aAa464F902BD2825CfBF6181`
- 거래: `0x49dd3cb387bbb6a35534e1e96c68ff25db08761bbf136e872d43810a8f4ffa5f`
- 블록: 12046353, 거래 성공 및 컴파일 산출물과 런타임 코드 일치 확인.
- 재확인: `node scripts/verify-deployment.mjs`
- 최초 실제 이용자 배지 발급은 별도 지갑 승인이 필요합니다.

## 새 컨트랙트가 필요한 경우 배포

1. MetaMask가 설치된 Chrome에서 `https://dinero108.github.io/web3-2026/?page=contract-deploy`를 엽니다.
2. MetaMask의 Sepolia 테스트넷에 연결합니다. Sepolia 테스트 ETH가 필요합니다. 실제 ETH는 보내지 않습니다.
3. 지갑 연결 후 배포 버튼을 누르고 MetaMask가 표시한 거래와 수수료를 검토한 뒤 직접 승인합니다.
4. 거래가 확정되면 화면에 컨트랙트 주소가 나옵니다. 이 주소는 현재 브라우저에만 저장됩니다.
5. 모든 이용자가 같은 컨트랙트를 쓰도록 `OFFICIAL_CONTRACT`에 검증한 주소를 넣고 다시 빌드/배포합니다. 현재는 위 검증된 배포 주소가 기본으로 연결되어 있습니다.

개인 키나 복구 문구는 코드/서버/GitHub에 저장하지 않습니다. 배포에는 사용자 지갑의 서명이 필요합니다.

## 사용

활동 증명에서 활동 선택 → 검증 파일 준비 → 파일 내려받기 → 공개 기록 동의 → 지갑에서 발급 승인. 검증 파일은 활동 원문을 포함하므로 사용자가 보관하고 선택적으로 공유합니다. 파일 원문과 무작위 salt는 네트워크로 보내지 않고, commitment만 전송합니다. 지갑 주소와 해시·발급 시점·취소 기록은 공개됩니다.

검증 파일은 발급 전 다운로드되므로 파일을 받았다고 발급이 완료된 것은 아닙니다. 실제 체인의 `receiptId`, `receipts`, `ownerOf`를 읽은 뒤에만 발급/유효 상태를 표시합니다. 파일 없이 해시에서 원문을 복원할 수 없습니다. 소유자는 취소할 수 있지만 과거 데이터는 삭제되지 않습니다.

동일 지갑·동일 commitment 재발급은 금지됩니다. 같은 활동이라도 새로운 무작위 salt로 만든 파일은 별개의 commitment가 됩니다. 이 기능은 활동 자체의 중복 여부를 판정하지 않습니다.

## 검증

```sh
npm ci
npm run contract:test
npm test
npm run build
```

계약 테스트: 실제 로컬 EVM 배포, 민팅, ERC721/5192 인터페이스, 빈/중복 해시, 양도 3종·승인 차단, 잘못된 tokenId, 타인의 취소 차단, 소유자 취소 및 중복 취소 차단.
사이트 테스트: 해시의 원문·수신자·컨트랙트·네트워크 포함, 무작위 salt, 변조/잘못된 파일 거부, 메인넷 서명 요청 차단.

운영 런타임 의존성 audit는 0건입니다. 개발용 Hardhat의 zod 의존성은 npm 감사 경고가 남아 있으므로 테스트 환경을 외부에 노출하지 않습니다. 이 테스트 통과는 독립 보안 감사나 운영 서비스 보증을 뜻하지 않습니다.

기준 문서: https://eips.ethereum.org/EIPS/eip-5192 / https://docs.openzeppelin.com/contracts/5.x/api/token/erc721 / https://docs.ethers.org/v6/getting-started/
