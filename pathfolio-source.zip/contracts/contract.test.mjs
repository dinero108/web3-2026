import assert from 'node:assert/strict';
import {test} from 'node:test';
import fs from 'node:fs';
import {network} from 'hardhat';
import {BrowserProvider,ContractFactory,keccak256,toUtf8Bytes} from 'ethers';
const artifact=JSON.parse(fs.readFileSync('src/generated/pathfolio-sbt.json','utf8'));
test('SBT contract enforces ownership, non-transferability, duplicates and revocation',async()=>{
 const connection=await network.create('test');const chain=connection.provider;
 try{
 const provider=new BrowserProvider(chain);provider.pollingInterval=10;
 const alice=await provider.getSigner(0),bob=await provider.getSigner(1);
 const contract=await new ContractFactory(artifact.abi,artifact.evm.bytecode.object,alice).deploy();await contract.waitForDeployment();
 const hash=keccak256(toUtf8Bytes('salted private record'));
 await (await contract.issueSelf(hash)).wait();
 assert.equal(await contract.ownerOf(1),await alice.getAddress());assert.equal(await contract.locked(1),true);
 assert.equal(await contract.supportsInterface('0xb45a3c0e'),true);assert.equal(await contract.supportsInterface('0x80ac58cd'),true);
 assert.equal((await contract.receipts(1)).commitment,hash);assert.equal((await contract.receipts(1)).revoked,false);
 await assert.rejects(()=>contract.issueSelf.staticCall(hash));
 await assert.rejects(()=>contract.issueSelf.staticCall('0x'+'0'.repeat(64)));
 await assert.rejects(()=>contract.transferFrom.staticCall(alice.address,bob.address,1));
 await assert.rejects(()=>contract['safeTransferFrom(address,address,uint256)'].staticCall(alice.address,bob.address,1));
 await assert.rejects(()=>contract['safeTransferFrom(address,address,uint256,bytes)'].staticCall(alice.address,bob.address,1,'0x'));
 await assert.rejects(()=>contract.approve.staticCall(bob.address,1));
 await assert.rejects(()=>contract.setApprovalForAll.staticCall(bob.address,true));
 await assert.rejects(()=>contract.connect(bob).revoke.staticCall(1));
 await assert.rejects(()=>contract.locked(999));
 await (await contract.revoke(1)).wait();assert.equal((await contract.receipts(1)).revoked,true);
 await assert.rejects(()=>contract.revoke.staticCall(1));assert.equal(await contract.ownerOf(1),alice.address);
 await (await contract.connect(bob).issueSelf(hash)).wait();assert.equal(await contract.ownerOf(2),bob.address);
 console.log('Checked mint, ERC-5192, 3 transfer paths, approvals, duplicate/empty commitment, ownership and revoke.');
 }finally{await connection.close();}
});
