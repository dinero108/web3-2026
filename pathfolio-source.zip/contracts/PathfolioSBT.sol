// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;
import "@openzeppelin/contracts/token/ERC721/ERC721.sol";

/// @notice Testnet self-record receipts. No institution endorsement or activity-truth claim.
/// @dev ERC-5192 permanently locked ERC-721. Only commitments, never activity text.
contract PathfolioSBT is ERC721 {
    struct Receipt { bytes32 commitment; uint64 issuedAt; bool revoked; }
    mapping(uint256 => Receipt) public receipts;
    mapping(address => mapping(bytes32 => bool)) public used;
    mapping(address => mapping(bytes32 => uint256)) public receiptId;
    uint256 public nextTokenId = 1;
    event Locked(uint256 tokenId);
    event SelfRecordIssued(uint256 indexed tokenId, address indexed recipient, bytes32 commitment);
    event ReceiptRevoked(uint256 indexed tokenId);
    error Soulbound();
    error EmptyCommitment();
    error DuplicateReceipt();
    error NotHolder();
    error AlreadyRevoked();

    constructor() ERC721("Pathfolio Self Record", "PATHSELF") {}
    function issueSelf(bytes32 commitment) external returns (uint256 tokenId) {
        if (commitment == bytes32(0)) revert EmptyCommitment();
        if (used[msg.sender][commitment]) revert DuplicateReceipt();
        used[msg.sender][commitment] = true;
        tokenId = nextTokenId++;
        receiptId[msg.sender][commitment] = tokenId;
        receipts[tokenId] = Receipt(commitment, uint64(block.timestamp), false);
        // Recipient is always the caller. No external callbacks or unsolicited recipient mints.
        _mint(msg.sender, tokenId);
        emit Locked(tokenId);
        emit SelfRecordIssued(tokenId, msg.sender, commitment);
    }
    function revoke(uint256 tokenId) external {
        if (ownerOf(tokenId) != msg.sender) revert NotHolder();
        if (receipts[tokenId].revoked) revert AlreadyRevoked();
        receipts[tokenId].revoked = true;
        emit ReceiptRevoked(tokenId);
    }
    function locked(uint256 tokenId) external view returns (bool) {
        _requireOwned(tokenId);
        return true;
    }
    function supportsInterface(bytes4 id) public view override returns (bool) {
        return id == 0xb45a3c0e || super.supportsInterface(id);
    }
    function approve(address, uint256) public pure override { revert Soulbound(); }
    function setApprovalForAll(address, bool) public pure override { revert Soulbound(); }
    function _update(address to, uint256 tokenId, address auth) internal override returns (address) {
        if (_ownerOf(tokenId) != address(0)) revert Soulbound();
        return super._update(to, tokenId, auth);
    }
}
